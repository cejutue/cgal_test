#define CGAL_USE_OSQP 1
#include "./include/utils.h"
#include "./include/Saver.h"
#include <CGAL/Simple_cartesian.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Shape_regularization/regularize_contours.h>
#include <CGAL/Alpha_shape_2.h>
#include <CGAL/Alpha_shape_vertex_base_2.h>
#include <CGAL/Alpha_shape_face_base_2.h>
#include <CGAL/algorithm.h>
#include <fstream>
#include <iostream>
#include <list>
#include <vector>
#include <CGAL/Shape_regularization/regularize_segments.h>
#include <CGAL/Eigen_diagonalize_traits.h>
#include <CGAL/linear_least_squares_fitting_2.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Shape_regularization/regularize_segments.h>
#include <CGAL/Delaunay_triangulation_2.h>

#pragma comment(lib,"osqp.lib")

#include <GeomathSE.cpp>
#include <Geomath2015.h>
#include <Geomath2015.cpp>
#include <gobject.inl>
using Kernel = CGAL::Simple_cartesian<double>;
using Point_2 = typename Kernel::Point_2;
typedef Kernel::FT                                                FT;
typedef Kernel::Point_2                                           Point;
typedef Kernel::Segment_2                                         Segment_2;
using Contour = std::vector<Point_2>;
using Contour_directions =
CGAL::Shape_regularization::Contours::Multiple_directions_2<Kernel, Contour>;


typedef CGAL::Alpha_shape_vertex_base_2<Kernel>                   Vb;
typedef CGAL::Alpha_shape_face_base_2<Kernel>                     Fb;
typedef CGAL::Triangulation_data_structure_2<Vb, Fb>          Tds;
typedef CGAL::Delaunay_triangulation_2<Kernel, Tds>                Triangulation_2;
typedef CGAL::Alpha_shape_2<Triangulation_2>                 Alpha_shape_2;
typedef Alpha_shape_2::Alpha_shape_edges_iterator            Alpha_shape_edges_iterator;
using Line_2 = typename Kernel::Line_2;
using Points_2 = std::vector<Point_2>;
using Indices = std::vector<std::size_t>;
using Segments = std::vector<Segment_2>;
using Neighbor_query =
CGAL::Shape_regularization::Segments::Delaunay_neighbor_query_2<Kernel, Segments>;
using Angle_regularization =
CGAL::Shape_regularization::Segments::Angle_regularization_2<Kernel, Segments>;
using Offset_regularization =
CGAL::Shape_regularization::Segments::Offset_regularization_2<Kernel, Segments>;
using Quadratic_program =
CGAL::OSQP_quadratic_program_traits<FT>;
using Quadratic_angle_regularizer =
CGAL::Shape_regularization::QP_regularization<
	Kernel, Segments, Neighbor_query, Angle_regularization, Quadratic_program>;
using Quadratic_offset_regularizer =
CGAL::Shape_regularization::QP_regularization<
	Kernel, Segments, Neighbor_query, Offset_regularization, Quadratic_program>;
template <class OutputIterator>
void alpha_edges(const Alpha_shape_2& A, OutputIterator out)
{
	Alpha_shape_edges_iterator it = A.alpha_shape_edges_begin(),
		end = A.alpha_shape_edges_end();
	for (; it != end; ++it)
		*out++ = A.segment(*it);
}
std::vector<Point_2> g_contour_Alpha;
void Alpha_shape(std::vector<Point_2>& points)
{
	Alpha_shape_2 A(points.begin(), points.end(),
		FT(0.5),
		Alpha_shape_2::GENERAL);
	std::vector<Segment_2> segments;
	alpha_edges(A, std::back_inserter(segments));
	points.clear();
	for (int i = 0; i < segments.size(); i++)
	{
		points.push_back(segments[i].vertex(0));
		points.push_back(segments[i].vertex(1));
	}
}

geostar::gsePath Convert(std::vector< std::vector<Point_2>>& out)
{

}

 double min_length_2 = double(5);
 double  max_angle_2 = double(30);
 double max_offset_2 = double(5);


std::vector<Point_2> coord_process(std::vector<Point_2>& contour, geostar::gseWriter& w)
{
	// Regularize.
	const bool is_closed = true;
	Contour_directions directions(
		contour, is_closed, CGAL::parameters::
		minimum_length(min_length_2).maximum_angle(max_angle_2));

	// Regularize this contour.
	std::vector<Point_2> regularized;
	CGAL::Shape_regularization::Contours::
		regularize_closed_contour(contour, directions, std::back_inserter(regularized),
			CGAL::parameters::maximum_offset(max_offset_2));

	std::vector<double>  tmp;
	for (int n = 0; n < regularized.size(); n++)
	{
		// std::cerr << regularized[n].x() << "--" << regularized[n].y() << std::endl;
		tmp.push_back(regularized[n].x());
		tmp.push_back(regularized[n].y());
	}
	if (regularized.size() > 0)
	{
		tmp.push_back(regularized[0].x());
		tmp.push_back(regularized[0].y());
	}
	else
		return regularized;

	geostar::gsePath g(geostar::g_f().create_single(2, tmp.size() / 2, 2, &tmp[0], 0, 0));
	_ga().gmodify(g, geostar::gmodify_force_good_dir, NULL);
	geostar::gsePath ptrGeo(_ga().prop_geo(g, geostar::prop_geo_simplify), 0);
	//C.push_back(g);
	w.Write(ptrGeo);
	return regularized;
}


void coord_debugsave(std::vector<Point_2>& contour, geostar::gseWriter& w,int gdim)
{
	std::vector<double>  tmp;
	for (int n = 0; n < contour.size(); n++)
	{
		// std::cerr << regularized[n].x() << "--" << regularized[n].y() << std::endl;
		tmp.push_back(contour[n].x());
		tmp.push_back(contour[n].y());
	}
	if (contour.size() > 0)
	{
		tmp.push_back(contour[0].x());
		tmp.push_back(contour[0].y());
	}
	else
		return;

	geostar::gsePath g(geostar::g_f().create_single(gdim, tmp.size() / 2, 2, &tmp[0], 0, 0));
	_ga().gmodify(g, geostar::gmodify_force_good_dir, NULL);
	geostar::gsePath ptrGeo(_ga().prop_geo(g, geostar::prop_geo_simplify), 0);
	w.Write(ptrGeo);
}
void coord_debugsave(std::vector<Segment_2>& segments, geostar::gseWriter& w, int gdim=1)
{
	std::vector<double>  tmp;
	
	for (int n = 0; n < segments.size(); n++)
	{
		tmp.clear();
		tmp.push_back(segments[n].vertex(0).x());
		tmp.push_back(segments[n].vertex(0).y());
		tmp.push_back(segments[n].vertex(1).x());
		tmp.push_back(segments[n].vertex(1).y());
		geostar::gsePath g(geostar::g_f().create_single(gdim, tmp.size() / 2, 2, &tmp[0], 0, 0));
		_ga().gmodify(g, geostar::gmodify_force_good_dir, NULL);
		geostar::gsePath ptrGeo(_ga().prop_geo(g, geostar::prop_geo_simplify), 0);
		w.Write(ptrGeo);
	}
}




std::vector<Point_2>  coord_process(double* p, int size, geostar::gseWriter& w)
{
	std::vector<Point_2> contour;
	for (int j = 0; j < size; j++)
	{
		g_contour_Alpha.push_back(Point_2(p[2 * j], p[2 * j + 1]));
		contour.push_back(Point_2(p[2 * j], p[2 * j + 1]));
	}
	contour.push_back(Point_2(p[0], p[1]));
	return coord_process(contour, w);

}
void signlepath_calc(geostar::gsePath& path, geostar::gseWriter& w)
{
	int ggg = path.NumSub();
	if (0 == ggg)
	{
		int pnum = path.NumPoint();
		double* p = path.PtrPoint();
		coord_process(p, pnum, w);
	}
	else
	{
		geostar::gsePathA  B;
		int ggg = path.NumSub();
		std::vector< std::vector<Point_2>> out;
		for (int k = 0; k < ggg; k++) {
			path.GetSubs(B);
			int pnum = B[k].NumPoint();
			double* p = B[k].PtrPoint();
			coord_process(p, pnum, w);
		}
	}
}

void regularize_real_data_2(std::vector<std::vector<Point_2>>& groups, geostar::gseWriter&fs_w)
{
	// Fit a line to each group of points.
	Line_2 line; Point_2 centroid;
	std::vector<Line_2> lines;
	lines.reserve(groups.size());
	for (const auto& group : groups) {
		CGAL::linear_least_squares_fitting_2(
			group.begin(), group.end(), line, centroid, CGAL::Dimension_tag<0>(),
			Kernel(), CGAL::Eigen_diagonalize_traits<FT, 2>());
		lines.push_back(line);
	}
	// Cut each line at the ends of the corresponding group.
	std::vector<Segment_2> segments;
	segments.reserve(lines.size());
	Point_2 source, target;
	for (std::size_t i = 0; i < lines.size(); ++i) {
		boundary_points_on_line_2(
			groups[i], lines[i], source, target);
		segments.push_back(Segment_2(source, target));
	}

	// Angle regularization.
	//const FT max_angle_2 = FT(80);
	// Create neigbor query and angle-based regularization model.
	Neighbor_query neighbor_query(segments);
	Angle_regularization angle_regularization(
		segments, CGAL::parameters::maximum_angle(max_angle_2));
	// Regularize.
	CGAL::Shape_regularization::Segments::regularize_segments(
		segments, neighbor_query, angle_regularization);
	std::cout << "* number of modified segments (angles) = " <<
		angle_regularization.number_of_modified_segments() << std::endl;
	// Offset regularization.
	//const FT max_offset_2 = FT(2);
	// Get groups of parallel segments after angle regularization.
	std::vector<Indices> pgroups;
	angle_regularization.parallel_groups(
		std::back_inserter(pgroups));
	// Create offset-based regularization model.
	Offset_regularization offset_regularization(
		segments, CGAL::parameters::maximum_offset(max_offset_2));
	// Add each group of parallel segments with at least 2 segments.
	neighbor_query.clear();
	for (const auto& pgroup : pgroups) {
		neighbor_query.add_group(pgroup);
		offset_regularization.add_group(pgroup);
	}
	// Regularize.
	CGAL::Shape_regularization::Segments::regularize_segments(
		segments, neighbor_query, offset_regularization);
	std::cout << "* number of modified segments (offsets) = " <<
		offset_regularization.number_of_modified_segments() << std::endl;
	// Save regularized segments.
	/*if (argc > 2) {
		const std::string full_path = std::string(argv[2]) + "regularize_real_data_2_after";
		saver.export_eps_segments(segments, full_path, FT(3) / FT(2));
	}*/
	coord_debugsave(segments, fs_w, 1);
}

void Testb()
{
	geostar::gseReader fs;
	fs.OpenGse("D:\\source\\kernel\\example\\cgal_test\\data\\wk.g2d");
	geostar::gseWriter fs_w;
	fs_w.OpenGse("D:\\source\\kernel\\example\\cgal_test\\data\\wk_w.g2d");
	//fs_w.Clear();
	auto paths = fs.Read();
	geostar::gsePathA A, B, C;
	paths.GetSubs(A);
	for (int i = 0; i < A.size(); i++)
	{
		geostar::gsePath d = A[i];
		signlepath_calc(d, fs_w);
		//geostar::gsePath gone;
		//gone.NewMulti(C.size(), &C[0]);

		//fs_w.Write(gone);
		//C.clear();
	}
	std::vector<std::vector<Point_2>>  jk;
	jk.push_back(g_contour_Alpha);
	regularize_real_data_2(jk, fs_w);
	Alpha_shape(g_contour_Alpha);
	coord_debugsave(g_contour_Alpha, fs_w, 0);
	//coord_process(g_contour_Alpha, fs_w);
}

#ifdef min
#undef min
#endif // min
#ifdef max
#undef max
#endif // min

void TestA()
{
	geostar::gseReader fs;
	fs.OpenText("D:\\source\\kernel\\example\\cgal_test\\data\\uu.txt");
	geostar::gseWriter fs_w;
	fs_w.OpenGse("D:\\source\\kernel\\example\\cgal_test\\data\\uua.g2d");
	//fs_w.Clear();
	
	geostar::gsePathA A, B, C;

	std::vector<Point_2> contour;
	std::vector<Segment_2> segments = {};
	while (auto segpath = fs.Read())
	{
		int pnum = segpath.NumPoint();
		double* p = segpath.PtrPoint();
		if (segpath.Length() < 0.6)
			continue;
		segments.push_back(Segment_2(Point_2(p[0], p[1]), Point_2(p[2], p[3])));
	}

	// Regularize all segments: both angles and offsets.&
	CGAL::Shape_regularization::Segments::
		regularize_segments(segments);
	std::vector<Segment_2> segmentsout = {};
	segmentsout.resize(segments.size());
	//CGAL::Shape_regularization::Segments::unique_segments(segments,&segmentsout[0]);

	
	for (int i = 0; i < segments.size(); i++)
	{
		std::vector<double> tmp = { segments[i].min().x(),segments[i].min().y(),segments[i].max().x(),segments[i].max().y() };

		//std::vector<double> tmp = { segmentsout[i].min().x(),segmentsout[i].min().y(),segmentsout[i].max().x(),segmentsout[i].max().y() };
		geostar::gsePath g(geostar::g_f().create_single(1, tmp.size() / 2, 2, &tmp[0], 0, 0));
		_ga().gmodify(g, geostar::gmodify_force_good_dir, NULL);
		geostar::gsePath ptrGeo(_ga().prop_geo(g, geostar::prop_geo_simplify), 0);
		fs_w.Write(ptrGeo);
	}
}

void TestC()
{
	geostar::gseReader fs;
	fs.OpenText("D:\\source\\kernel\\example\\cgal_test\\data\\uu.txt");
	geostar::gseWriter fs_w;
	fs_w.OpenGse("D:\\source\\kernel\\example\\cgal_test\\data\\uuc.g2d");
	//fs_w.Clear();

	geostar::gsePathA A, B, C;

	std::vector<Point_2> contour;
	while (auto segpath = fs.Read())
	{
		int pnum = segpath.NumPoint();
		double* p = segpath.PtrPoint();
		contour.push_back(Point_2(p[0], p[1]));
		contour.push_back( Point_2(p[2], p[3]));
	}

	// Regularize.
	const bool is_closed = true;
	Contour_directions directions(
		contour, is_closed, CGAL::parameters::
		minimum_length(min_length_2).maximum_angle(max_angle_2));

	// Regularize this contour.
	std::vector<Point_2> regularized;
	CGAL::Shape_regularization::Contours::
		regularize_closed_contour(contour, directions, std::back_inserter(regularized),
			CGAL::parameters::maximum_offset(max_offset_2));

	std::vector<double>  tmp;
	for (int n = 0; n < regularized.size(); n++)
	{
		// std::cerr << regularized[n].x() << "--" << regularized[n].y() << std::endl;
		tmp.push_back(regularized[n].x());
		tmp.push_back(regularized[n].y());
	}
	if (regularized.size() > 0)
	{
		tmp.push_back(regularized[0].x());
		tmp.push_back(regularized[0].y());
	}
	else
		return;

	geostar::gsePath g(geostar::g_f().create_single(1, tmp.size() / 2, 2, &tmp[0], 0, 0));
	_ga().gmodify(g, geostar::gmodify_force_good_dir, NULL);
	geostar::gsePath ptrGeo(_ga().prop_geo(g, geostar::prop_geo_simplify), 0);
	fs_w.Write(ptrGeo);
}

/// \brief �򵥵�write
void vector_wc(void* user, geostar::geo_object* R)
{
	if (R == 0) return;
	((std::vector<geostar::gobjptr>*)user)->push_back(R);
}

void TestD_n_union()
{
	geostar::gseReader fs;
	fs.OpenGse("D:\\source\\kernel\\example\\cgal_test\\data\\step.g2d");
	geostar::gseWriter fs_w;
	fs_w.OpenGse("D:\\source\\kernel\\example\\cgal_test\\data\\step_u.g2d");
	//fs_w.Clear();

	geostar::gsePathA A;
	std::vector<Point_2> contour;
	std::vector<geostar::gobjptr> B;

	geostar::geo_writer* W1 = _gf().new_writer(&B, vector_wc);
	_ga().n_union(fs, W1);//ֻ֧�ֶ������
	//BӦ��ֻ�� һ��
	geostar::gsePath segpath(B[0]);
	fs_w.Write(segpath);
	int pnum = segpath.NumPoint();
	double* p = segpath.PtrPoint();

	min_length_2 = double(10);
	max_angle_2 = double(89);
	max_offset_2 = double(10);
	std::vector<Point_2>  g = coord_process(p, pnum, fs_w);
	min_length_2 = double(2);
	max_angle_2 = double(20);
	max_offset_2 = double(2);
	
	coord_process(g, fs_w);
	W1->release();
}
int main() {

	CGAL::bounding_box(point_set.points().begin(), point_set.points().end());
	TestD_n_union();
	//TestC();

}
