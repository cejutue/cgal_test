#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Surface_mesh.h>
#include <CGAL/Surface_mesh.h>
#include <CGAL/Surface_mesh/IO.h>
#include <CGAL/intersections.h>
#include <CGAL/Polygon_mesh_processing/corefinement.h>
#include <CGAL/Polygon_mesh_processing/orient_polygon_soup.h>
#include <CGAL/Polygon_mesh_processing/polygon_soup_to_polygon_mesh.h>


#include <CGAL/exceptions.h>

#include <CGAL/Exact_integer.h>
#include <CGAL/Homogeneous.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Polygon_mesh_processing/triangulate_hole.h>
#include <CGAL/Polygon_mesh_processing/border.h>
#include <CGAL/Polygon_mesh_processing/repair_polygon_soup.h>
#include <CGAL/Polygon_mesh_processing/repair_self_intersections.h>
#include <CGAL/Polygon_mesh_processing/repair_degeneracies.h>
#include <CGAL/Polygon_mesh_processing/orientation.h>
#include <CGAL/Polygon_mesh_processing/fair.h>
#include <CGAL/Polygon_mesh_processing/refine.h>
#include <CGAL/Polygon_mesh_processing/polygon_soup_to_polygon_mesh.h>
#include <CGAL/Polygon_mesh_processing/stitch_borders.h>
#include <CGAL/Polygon_mesh_processing/triangulate_faces.h >
#include <boost/lexical_cast.hpp>
#include <CGAL/version_macros.h>
#include <CGAL/Surface_mesh_approximation/approximate_triangle_mesh.h>
//#if (CGAL_VERSION <= 5.5)
//#include <CGAL/IO/obj_reader.h>
//#include <CGAL/IO/File_writer_wavefront.h>
//#include <CGAL/IO/generic_copy_OFF.h>
//#else
#include <CGAL/Polygon_mesh_processing/IO/polygon_mesh_io.h>
#include <CGAL/IO/OBJ/File_writer_wavefront.h>
#include <CGAL/IO/obj.h>
//#endif
#include <fstream>
#include<iostream>
#include<filesystem>
using namespace std;
typedef CGAL::Exact_predicates_inexact_constructions_kernel K;
typedef K::Point_3 Point;
typedef CGAL::Surface_mesh<K::Point_3>             Mesh;
typedef CGAL::Polyhedron_3<K>  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>  Nef_polyhedron;
typedef boost::graph_traits<Mesh>::halfedge_descriptor   halfedge_descriptor;
typedef boost::graph_traits<Mesh>::face_descriptor       face_descriptor;
typedef boost::graph_traits<Mesh>::vertex_descriptor     vertex_descriptor;
namespace PMP = CGAL::Polygon_mesh_processing;
namespace NP = CGAL::parameters;
namespace VSA = CGAL::Surface_mesh_approximation;

void holeFilling(Mesh& mesh);

#define  READ_HANDLE std::string
#define  WRITE_HANDLE std::string
bool load_obj(std::string & in, Mesh& m)
{
    bool failed = CGAL::Polygon_mesh_processing::IO::read_polygon_mesh(in, m);
    
    //����ȷ���պ϶�����������������ķ���ʹ���޶�һ�����
    if (CGAL::is_closed(m))
        CGAL::Polygon_mesh_processing::orient_to_bound_a_volume(m);

    //���ͬһ�߽�İ�ߣ����λ�ڲ�ͬ�߽��ϵİ�ߡ����Դ������ཻ����--��������Ӧ�������ε�
    CGAL::Polygon_mesh_processing::stitch_borders(m);

    std::vector<std::vector<vertex_descriptor> > duplicated_vertices;
    std::size_t new_vertices_nb = PMP::duplicate_non_manifold_vertices(m,
        NP::output_iterator(
            std::back_inserter(duplicated_vertices)));
    //�ڿ��ܵ�����ºϲ������������������
    PMP::merge_reversible_connected_components(m);

    bool b = CGAL::Polygon_mesh_processing::does_self_intersect(m);
    b = CGAL::Polygon_mesh_processing::does_bound_a_volume(m);

    holeFilling(m);

    return failed;
}


bool save_obj(std::ostream & out, Mesh& m)
{
    //CGAL::File_writer_wavefront  writer;
    //CGAL::generic_print_surface_mesh(out, m, writer);
    //return out.good();
    return CGAL::IO::write_OBJ(out, m);
}
//
//bool load_obj(std::istream& in, Mesh&m)
//{
//    typedef Mesh::Point Point;
//    std::vector<Point> points;
//    std::vector<std::vector<std::size_t> > faces;
//    bool failed = !CGAL::read_OBJ(in, points, faces);
//    //ȥ����������еĹ�����
//    //�ϲ���������е��ظ���
//    //�ϲ���������е��ظ������
//    //ȥ����������еĹ�����
//    CGAL::Polygon_mesh_processing::repair_polygon_soup(points, faces);
//    PMP::orient_polygon_soup(points, faces);
//    PMP::polygon_soup_to_polygon_mesh(points, faces, (m));
//    CGAL::Polygon_mesh_processing::repair_polygon_soup(points, faces);
//    
//    //����ȷ���պ϶�����������������ķ���ʹ���޶�һ�����
//    if (CGAL::is_closed(m))
//        CGAL::Polygon_mesh_processing::orient_to_bound_a_volume(m);
//
//    //���ͬһ�߽�İ�ߣ����λ�ڲ�ͬ�߽��ϵİ�ߡ����Դ������ཻ����--��������Ӧ�������ε�
//    CGAL::Polygon_mesh_processing::stitch_borders(m);
// 
//    std::vector<std::vector<vertex_descriptor> > duplicated_vertices;
//    std::size_t new_vertices_nb = PMP::duplicate_non_manifold_vertices(m,
//        NP::output_iterator(
//            std::back_inserter(duplicated_vertices)));
//    //�ڿ��ܵ�����ºϲ������������������
//    PMP::merge_reversible_connected_components(m);
//
//    bool b = CGAL::Polygon_mesh_processing::does_self_intersect(m);
//    b = CGAL::Polygon_mesh_processing::does_bound_a_volume(m);
//    
//    holeFilling(m);
//
//    if ((!failed) )
//    {
//        return true;
//    }
//    return false;
//}
//
//bool save_obj(std::ostream& out,Mesh&m) 
//{
//    //cgal 5.1.5
//    CGAL::File_writer_wavefront  writer;
//    CGAL::generic_print_surface_mesh(out, m, writer);
//    return out.good();
//}

bool IsSimple(Mesh& m)
{
    if (!CGAL::is_closed(m))
        return false;
    if (!CGAL::Polygon_mesh_processing::does_self_intersect(m))
        return false;
    if (!CGAL::Polygon_mesh_processing::does_bound_a_volume(m))
        return false;
    return true;
}
bool Repair(Mesh& m)
{
    //����ȷ���պ϶�����������������ķ���ʹ���޶�һ�����
    if (CGAL::is_closed(m))
        CGAL::Polygon_mesh_processing::orient_to_bound_a_volume(m);

    //�ڿ��ܵ�����ºϲ������������������
    PMP::merge_reversible_connected_components(m);

    std::vector<std::vector<vertex_descriptor> > duplicated_vertices;
    std::size_t new_vertices_nb = PMP::duplicate_non_manifold_vertices(m,
        NP::output_iterator(
            std::back_inserter(duplicated_vertices)));


    //���ͬһ�߽�İ�ߣ����λ�ڲ�ͬ�߽��ϵİ�ߡ����Դ������ཻ����--��������Ӧ�������ε�
    CGAL::Polygon_mesh_processing::stitch_borders(m);
    bool b = CGAL::Polygon_mesh_processing::does_self_intersect(m);
    b = CGAL::Polygon_mesh_processing::does_bound_a_volume(m);

    holeFilling(m);
}

//���������������
bool mesh_approximation(Mesh& m) {
    // The output will be an indexed triangle mesh
    std::vector<K::Point_3> anchors;
    std::vector<std::array<std::size_t, 3> > triangles;
    // free function interface with named parameters
    VSA::approximate_triangle_mesh(m,
        CGAL::parameters::verbose_level(VSA::MAIN_STEPS).
        max_number_of_proxies(200).
        anchors(std::back_inserter(anchors)). // anchor points
        triangles(std::back_inserter(triangles))); // indexed triangles
}
bool is_small_hole(halfedge_descriptor h, Mesh& mesh,
    double max_hole_diam, int max_num_hole_edges)
{
    int num_hole_edges = 0;
    CGAL::Bbox_3 hole_bbox;
    for (halfedge_descriptor hc : CGAL::halfedges_around_face(h, mesh))
    {
        const Point& p = mesh.point(target(hc, mesh));
        hole_bbox += p.bbox();
        ++num_hole_edges;
        // Exit early, to avoid unnecessary traversal of large holes
        if (num_hole_edges > max_num_hole_edges) return false;
        if (hole_bbox.xmax() - hole_bbox.xmin() > max_hole_diam) return false;
        if (hole_bbox.ymax() - hole_bbox.ymin() > max_hole_diam) return false;
        if (hole_bbox.zmax() - hole_bbox.zmin() > max_hole_diam) return false;
    }
    return true;
}

void holeFilling(Mesh& mesh)
{
    double max_hole_diam =  -1.0;
    int max_num_hole_edges =  -1;
    unsigned int nb_holes = 0;
    std::vector<halfedge_descriptor> border_cycles;
    // collect one halfedge per boundary cycle
    CGAL::Polygon_mesh_processing::extract_boundary_cycles(mesh, std::back_inserter(border_cycles));
    for (halfedge_descriptor h : border_cycles)
    {
        if (max_hole_diam > 0 && max_num_hole_edges > 0 &&
            !is_small_hole(h, mesh, max_hole_diam, max_num_hole_edges))
            continue;
        std::vector<face_descriptor>  patch_facets;
        std::vector<vertex_descriptor> patch_vertices;
        bool success = std::get<0>(
            CGAL::Polygon_mesh_processing::triangulate_refine_and_fair_hole(
                mesh,
                h,
                std::back_inserter(patch_facets),
                std::back_inserter(patch_vertices)));
        std::cout << "* Number of facets in constructed patch: " << patch_facets.size() << std::endl;
        std::cout << "  Number of vertices in constructed patch: " << patch_vertices.size() << std::endl;
        std::cout << "  Is fairing successful: " << success << std::endl;
        ++nb_holes;
    }

}

void meshUnion(std::vector<Mesh>& m, Mesh & out)
{
    if (m.size() == 2)
    {
        std::ofstream input2("D:\\testdata\\3DBOOL\\out\\0.obj");
        save_obj(input2, m[0]);
        input2.close();
        std::ofstream input1("D:\\testdata\\3DBOOL\\out\\1.obj");
        save_obj(input1, m[1]);
        input1.close();
    }
    if (m.size() <= 1)
    {
        out = m[0];
        return;
    }
    std::vector<Mesh> temp;
    for (int i = 0;i < 2 || i < m.size(); i += 2)
    {
        if (i + 1 >= m.size())
        {       
            temp.push_back(m[i]);
            break;
        }
        Mesh outtmp;
        Repair(m[i]);
        Repair(m[i+1]);
        bool valid_union = PMP::corefine_and_compute_union(m[i], m[i+1], outtmp);
        //PMP::triangulate_faces(outtmp);
        //repair_polygon_soup(outtmp);
        std::ostringstream oss;
        oss.str("");
        oss << "D:\\testdata\\3DBOOL\\out\\" << m.size() << "_" << i << "_" << i + 1 << ".obj";
        std::ofstream input1(oss.str().c_str());
        save_obj(input1, outtmp);
        input1.close();
        temp.push_back(outtmp);
    }
    
    meshUnion(temp, out);
}


void meshUnion2(std::vector<Mesh>& m, Mesh& out)
{
    if (m.size() <= 1)
    {
        out = m[0];
        return;
    }
    std::vector<Mesh> temp;
    Mesh outtmp= m[0];
   
    for (int i = 1;i < m.size(); i++)
    {
        Mesh out1;
        bool valid_union = PMP::corefine_and_compute_union(outtmp, m[i], out1);
        outtmp = std::move(out1);
    }
    out = std::move(outtmp);
}




int testtwo(int argc, char* argv[])
{
    //const char* filename1 = (argc > 1) ? argv[1] : u8"D:\\testdata\\3DBOOL\\temp\\05.obj";
    //const char* filename2 = (argc > 2) ? argv[2] : u8"D:\\testdata\\3DBOOL\\temp\\06.obj";
    //const char* filename1 = (argc > 1) ? argv[1] : u8"D:\\testdata\\3DBOOL\\temp\\05.off";
    //const char* filename2 = (argc > 2) ? argv[2] : u8"D:\\testdata\\3DBOOL\\temp\\06.off";
    std::string filename1 = (argc > 1) ? argv[1] : u8"D:\\testdata\\3DBOOL\\6_0_1.obj";
    std::string filename2 = (argc > 2) ? argv[2] : u8"D:\\testdata\\3DBOOL\\6_2_3.obj";



    std::ifstream input(filename1);

    Mesh mesh1, mesh2;
    if (!load_obj(filename1, mesh1))
    //if (!load_obj(input, mesh1))
    //if (!input || !(input >> mesh1))
    {
        std::cerr << "First mesh is not a valid off file." << std::endl;
        return 1;
    }
    input.close();
    input.open(filename2);
    if (!load_obj(filename2, mesh2))
    //if (!load_obj(input, mesh2))
    //if (!input || !(input >> mesh2))
    {
        std::cerr << "Second mesh is not a valid off file." << std::endl;
        return 1;
    }


    Mesh out;
    IsSimple(mesh1);
    IsSimple(mesh2);
    Repair(mesh1);
    Repair(mesh2);
    bool valid_union = PMP::corefine_and_compute_union(mesh1, mesh2, out);
    std::ofstream input1("D:\\testdata\\3DBOOL\\m1.obj");
    save_obj(input1, mesh1);
    std::ofstream input2("D:\\testdata\\3DBOOL\\m2.obj");
    save_obj(input2, mesh2);
    if (valid_union)
    {
        std::cout << "Union was successfully computed\n";
        std::ofstream output("D:\\testdata\\3DBOOL\\temp\\union.off");
        output.precision(17);
        output << out;
        return 0;
    }
    std::cout << "Union could not be computed\n";
}
int main(int argc, char* argv[])
{
    //return testtwo( argc,  argv);

    const char* filename1 = (argc > 1) ? argv[1] : u8"D:\\testdata\\3DBOOL\\temp\\";

    const char* outfilename = (argc > 2) ? argv[2] : u8"D:\\testdata\\3DBOOL\\out\\";
    std::string outpath = outfilename;
    bool isFirst = true,flag =true;
    Mesh   out;
    std::vector<Mesh> mtmps;
    for (auto& i : std::filesystem::directory_iterator(filename1)) {
        Mesh mesh1, mesh2, out;
        cout << i.path().string() << endl;
        if (i.path().string().find(".obj") == std::string::npos)
        {
            continue;
        }
        std::string gtmp = i.path().string();
        std::ifstream input2(gtmp);
        if (load_obj(gtmp, mesh2))
        //if (load_obj(input2, mesh2)) 
        {
            std::string tmp = outpath;
            tmp.append(i.path().filename().string());
            std::ofstream input2(tmp);
            save_obj(input2, mesh2);

            mtmps.push_back(mesh2);
            //bool valid_union = PMP::corefine_and_compute_union(mesh1, mesh2, out);
            ////mesh1.assign(out);
            input2.close();
        }

 
    }
    meshUnion(mtmps, out);
    PMP::triangulate_faces(out);
    outpath =  outpath.append("union.obj");
    std::ofstream input2(outpath.c_str());
    save_obj(input2, out);

  return 1;
}
