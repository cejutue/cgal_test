﻿#include <fstream>
#include <iostream>  
#include <vector>  
#include <unordered_set>  
#include <algorithm>  
#include "knn/knn_.h"

#include <CGAL/Real_timer.h>
#include <CGAL/Random.h>
#include <CGAL/Simple_cartesian.h>
#include <CGAL/Point_set_2.h>
#include <CGAL/Point_set_3.h>
#include <CGAL/Point_set_3/IO.h>
#include <CGAL/jet_estimate_normals.h>
#include <CGAL/Shape_detection/Region_growing/Region_growing.h>
#include <CGAL/Shape_detection/Region_growing/Region_growing_on_point_set.h>
#include <CGAL/Shape_detection/Efficient_RANSAC.h>
#include <boost/iterator/function_output_iterator.hpp>
#include <CGAL/Surface_mesh_segmentation/internal/K_means_clustering.h>



enum class region_growing_Type
{
	ePlane,
	eCylinder,
	eSphere,
	eCircle,
	eLine
};

struct region_prarams
{
	bool IsRansac = true;
	region_growing_Type type;
	// Default parameters for data/cube.pwn
	std::size_t k = 24;
	double distance_threshold = 0.05;
	double angle_threshold = 5.;
	std::size_t min_region_size = 200;

	// No constraint on radius
	double min_radius = 0.;
	double max_radius = std::numeric_limits<double>::infinity();
};


using Kernel = CGAL::Simple_cartesian<double>;
using Point_3 = Kernel::Point_3;
using Vector_3 = Kernel::Vector_3;
using Point_2 = Kernel::Point_2;
using Vector_2 = Kernel::Vector_2;

using Point_set = CGAL::Point_set_3<Point_3>;
using Point_map = typename Point_set::Point_map;
using Normal_map = typename Point_set::Vector_map;

namespace Shape_detection = CGAL::Shape_detection::Point_set;

using Neighbor_query = Shape_detection::K_neighbor_query
<Kernel, Point_set, Point_map>;

using Region_type_cylinder = Shape_detection::Least_squares_cylinder_fit_region  <Kernel, Point_set, Point_map, Normal_map>;
using Region_type_line = Shape_detection::Least_squares_line_fit_region <Kernel, Point_set, Point_map, Normal_map>;
using Region_type_circle = Shape_detection::Least_squares_circle_fit_region <Kernel, Point_set, Point_map, Normal_map>;
using Region_type_plane = Shape_detection::Least_squares_plane_fit_region <Kernel, Point_set, Point_map, Normal_map>;
using Region_type_sphere = Shape_detection::Least_squares_sphere_fit_region <Kernel, Point_set, Point_map, Normal_map>;

template<typename T>
using Region_growing_run = CGAL::Shape_detection::Region_growing
<Point_set, Neighbor_query, T>;

//
//using Traits = CGAL::Shape_detection::Efficient_RANSAC_traits< Kernel,
//	Point_set,
//	CGAL::Identity_property_map
//	<typename std::iterator_traits<typename Point_map::iterator>::value_type>,
//	CGAL::Identity_property_map
//	<typename std::iterator_traits<typename Normal_map::iterator>::value_type> > ;
using Traits = CGAL::Shape_detection::Efficient_RANSAC_traits< Kernel,
	Point_set,
	Point_map,Normal_map >;

//typedef CGAL::Shape_detection::internal::RANSAC_octree<Traits> Direct_octree;

using Efficient_ransac = CGAL::Shape_detection::Efficient_RANSAC<Traits>;
using Cone = CGAL::Shape_detection::Cone<Traits>             ;
using Cylinder = CGAL::Shape_detection::Cylinder<Traits>     ;
using Plane = CGAL::Shape_detection::Plane<Traits>           ;
using Sphere = CGAL::Shape_detection::Sphere<Traits>         ;
using Torus = CGAL::Shape_detection::Torus<Traits>           ;


int ransac(Point_set & points, region_prarams & params)
{
	// Instantiate shape detection engine.
	Efficient_ransac ransac;

	// Provide input data.
	ransac.set_input(points, points.point_map(), points.normal_map());

	// Register shapes for detection.
	ransac.add_shape_factory<Plane>();
	ransac.add_shape_factory<Sphere>();
	ransac.add_shape_factory<Cylinder>();
	ransac.add_shape_factory<Cone>();
	ransac.add_shape_factory<Torus>();

	// Set parameters for shape detection.
	Efficient_ransac::Parameters parameters;

	// Set probability to miss the largest primitive at each iteration.
	parameters.probability = 0.05;

	// Detect shapes with at least 200 points.
	parameters.min_points = 200;

	// Set maximum Euclidean distance between a point and a shape.
	parameters.epsilon = 0.002;

	// Set maximum Euclidean distance between points to be clustered.
	parameters.cluster_epsilon = 0.01;

	// Set maximum normal deviation.
	// 0.9 < dot(surface_normal, point_normal);
	parameters.normal_threshold = 0.9;

	// Detect shapes.
	ransac.detect();
	std::cout << "-----detected shapes start-----" << std::endl;
	// Print number of detected shapes and unassigned points.
	std::cout << ransac.shapes().end() - ransac.shapes().begin()
		<< " detected shapes, "
		<< ransac.number_of_unassigned_points()
		<< " unassigned points." << std::endl;

	// Efficient_ransac::shapes() provides
	// an iterator range to the detected shapes.
	Efficient_ransac::Shape_range shapes = ransac.shapes();
	Efficient_ransac::Shape_range::iterator it = shapes.begin();
	Point_set::Property_map<unsigned char>
		red = points.add_property_map<unsigned char>("red", 0).first,
		green = points.add_property_map<unsigned char>("green", 0).first,
		blue = points.add_property_map<unsigned char>("blue", 0).first;
	CGAL::Random random;

	while (it != shapes.end()) {
		unsigned char r = static_cast<unsigned char>(random.get_int(64, 192));
		unsigned char g = static_cast<unsigned char>(random.get_int(64, 192));
		unsigned char b = static_cast<unsigned char>(random.get_int(64, 192));
		// Get specific parameters depending on the detected shape.
		if (Plane* plane = dynamic_cast<Plane*>(it->get())) {

			r = 255;
			g = 0;
			b = 0;

			Kernel::Vector_3 normal = plane->plane_normal();
			std::cout << "Plane with normal " << normal << std::endl;

			// Plane shape can also be converted to the Kernel::Plane_3.
			std::cout << "Kernel::Plane_3: " <<
				static_cast<Kernel::Plane_3>(*plane) << std::endl;

		}
		else if (Cylinder* cyl = dynamic_cast<Cylinder*>(it->get())) {

			r = 0;
			g = 255;
			b = 0;

			Kernel::Line_3 axis = cyl->axis();
			double radius = cyl->radius();

			std::cout << "Cylinder with axis "
				<< axis << " and radius " << radius << std::endl;

		}
		else if (Sphere* cyl = dynamic_cast<Sphere*>(it->get())) {
			r = 0;
			g = 0;
			b = 255;
			std::cout << (*it)->info() << std::endl;
		}
		else if (Cone* cyl = dynamic_cast<Cone*>(it->get())) {
			r = 255;
			g = 255;
			b = 255;
			std::cout << (*it)->info() << std::endl;
		}
		else if (Torus* cyl = dynamic_cast<Torus*>(it->get())) {
			r = 255;
			g = 0;
			b = 255;
			std::cout << (*it)->info() << std::endl;
		}
		else {
			r = 0;
			g = 0;
			b = 0;
			// Print the parameters of the detected shape.
			// This function is available for any type of shape.
			std::cout << (*it)->info() << std::endl;
		}

		std::vector<std::size_t>::const_iterator
			index_it = (*it)->indices_of_assigned_points().begin();

		while (index_it != (*it)->indices_of_assigned_points().end()) {

			// Retrieve point.
			//auto & p = *(points.begin() + (*index_it));

			

			red[*index_it] = r;
			green[*index_it] = g;
			blue[*index_it] = b;
			
			index_it++;
		}

		it++;
	}


	std::cout 	<< "----detected shapes end-----"<<std::endl;
}

//using Region_growing = CGAL::Shape_detection::Region_growing
//  <Point_set, Neighbor_query, Region_type>;




int Region_growing_plane(Point_set& points, region_prarams& params)
{


	std::cerr << points.size() << " points read" << std::endl;

	// Input should have normals
	//assert (points.has_normal_map());
	if (!points.has_normal_map())
	{
		points.add_normal_map();
		CGAL::jet_estimate_normals<CGAL::Sequential_tag>(points, 8, points.parameters().degree_fitting(2));
	}

	// Default parameters for data/cube.pwn
	const std::size_t k = params.k;
	const double tolerance = params.distance_threshold;
	const double max_angle = params.angle_threshold;
	const std::size_t min_region_size = params.min_region_size;

	// No constraint on radius
	const double min_radius = params.min_radius;
	const double max_radius = params.max_radius;


	Neighbor_query neighbor_query(points, k, points.point_map());
	Region_type_plane region_type(points, tolerance, max_angle, min_region_size,
		points.point_map(), points.normal_map());
	Region_growing_run<Region_type_plane> region_growing(points, neighbor_query, region_type);

	// Add maps to get colored output
	Point_set::Property_map<unsigned char>
		red = points.add_property_map<unsigned char>("red", 0).first,
		green = points.add_property_map<unsigned char>("green", 0).first,
		blue = points.add_property_map<unsigned char>("blue", 0).first;

	CGAL::Random random;

	std::size_t nb_cylinders = 0;

	region_growing.detect
	(boost::make_function_output_iterator
	([&](const std::vector<std::size_t>& region)
		{
			// Assign a random color to each region
			unsigned char r = static_cast<unsigned char>(random.get_int(64, 192));
			unsigned char g = static_cast<unsigned char>(random.get_int(64, 192));
			unsigned char b = static_cast<unsigned char>(random.get_int(64, 192));
			for (const std::size_t& idx : region)
			{
				red[idx] = r;
				green[idx] = g;
				blue[idx] = b;
			}
			++nb_cylinders;
		}));


	return EXIT_SUCCESS;
}

int Region_growing_cylinder(Point_set& points, region_prarams& params)
{

	std::cerr << points.size() << " points read" << std::endl;

	// Input should have normals
	//assert (points.has_normal_map());
	if (!points.has_normal_map())
	{
		points.add_normal_map();
		CGAL::jet_estimate_normals<CGAL::Sequential_tag>(points, 8, points.parameters().degree_fitting(2));
	}

	// Default parameters for data/cube.pwn
	const std::size_t k = params.k;
	const double tolerance = params.distance_threshold;
	const double max_angle = params.angle_threshold;
	const std::size_t min_region_size = params.min_region_size;

	// No constraint on radius
	const double min_radius = params.min_radius;
	const double max_radius = params.max_radius;


	Neighbor_query neighbor_query(points, k, points.point_map());
	Region_type_cylinder region_type(points, tolerance, max_angle, min_region_size,
		min_radius, max_radius,
		points.point_map(), points.normal_map());
	Region_growing_run<Region_type_cylinder> region_growing(points, neighbor_query, region_type);

	// Add maps to get colored output
	Point_set::Property_map<unsigned char>
		red = points.add_property_map<unsigned char>("red", 0).first,
		green = points.add_property_map<unsigned char>("green", 0).first,
		blue = points.add_property_map<unsigned char>("blue", 0).first;

	CGAL::Random random;

	std::size_t nb_cylinders = 0;

	region_growing.detect
	(boost::make_function_output_iterator
	([&](const std::vector<std::size_t>& region)
		{
			// Assign a random color to each region
			unsigned char r = static_cast<unsigned char>(random.get_int(64, 192));
			unsigned char g = static_cast<unsigned char>(random.get_int(64, 192));
			unsigned char b = static_cast<unsigned char>(random.get_int(64, 192));
			for (const std::size_t& idx : region)
			{
				red[idx] = r;
				green[idx] = g;
				blue[idx] = b;
			}
			++nb_cylinders;
		}));


	return EXIT_SUCCESS;
}

int Region_growing_sphere(Point_set& points, region_prarams& params)
{

	std::cerr << points.size() << " points read" << std::endl;

	if (!points.has_normal_map())
	{
		points.add_normal_map();
		CGAL::jet_estimate_normals<CGAL::Sequential_tag>(points, 8, points.parameters().degree_fitting(2));
	}

	// Default parameters for data/cube.pwn
	const std::size_t k = params.k;
	const double tolerance = params.distance_threshold;
	const double max_angle = params.angle_threshold;
	const std::size_t min_region_size = params.min_region_size;

	// No constraint on radius
	const double min_radius = params.min_radius;
	const double max_radius = params.max_radius;


	Neighbor_query neighbor_query(points, k, points.point_map());
	Region_type_sphere region_type(points, tolerance, max_angle, min_region_size,
		min_radius, max_radius,
		points.point_map(), points.normal_map());
	Region_growing_run<Region_type_sphere> region_growing(points, neighbor_query, region_type);

	// Add maps to get colored output
	Point_set::Property_map<unsigned char>
		red = points.add_property_map<unsigned char>("red", 0).first,
		green = points.add_property_map<unsigned char>("green", 0).first,
		blue = points.add_property_map<unsigned char>("blue", 0).first;

	CGAL::Random random;

	std::size_t nb_cylinders = 0;
	region_growing.detect
	(boost::make_function_output_iterator
	([&](const std::vector<std::size_t>& region)
		{
			// Assign a random color to each region
			unsigned char r = static_cast<unsigned char>(random.get_int(64, 192));
			unsigned char g = static_cast<unsigned char>(random.get_int(64, 192));
			unsigned char b = static_cast<unsigned char>(random.get_int(64, 192));
			for (const std::size_t& idx : region)
			{
				red[idx] = r;
				green[idx] = g;
				blue[idx] = b;
			}
			++nb_cylinders;
		}));


	return EXIT_SUCCESS;
}

//int Region_growing_circle(Point_set& points, region_prarams& params)
//{
//	std::cerr << points.size() << " points read" << std::endl;
//
//	// Input should have normals
//	//assert (points.has_normal_map());
//	if (!points.has_normal_map())
//	{
//		points.add_normal_map();
//		CGAL::jet_estimate_normals<CGAL::Sequential_tag>(points, 8, points.parameters().degree_fitting(2));
//	}
//
//	// Default parameters for data/cube.pwn
//	const std::size_t k = params.k;
//	const double tolerance = params.distance_threshold;
//	const double max_angle = params.angle_threshold;
//	const std::size_t min_region_size = params.min_region_size;
//
//	// No constraint on radius
//	const double min_radius = params.min_radius;
//	const double max_radius = params.max_radius;
//
//
//	Neighbor_query neighbor_query(points, k, points.point_map());
//	Region_type_circle region_type(points, tolerance, max_angle, min_region_size,
//		min_radius, max_radius, points.point_map(), points.normal_map());
//	Region_growing_run<Region_type_circle> region_growing(points, neighbor_query, region_type);
//
//	// Add maps to get colored output
//	Point_set::Property_map<unsigned char>
//		red = points.add_property_map<unsigned char>("red", 0).first,
//		green = points.add_property_map<unsigned char>("green", 0).first,
//		blue = points.add_property_map<unsigned char>("blue", 0).first;
//
//	CGAL::Random random;
//
//	std::size_t nb_cylinders = 0;
//
//	region_growing.detect
//	(boost::make_function_output_iterator
//	([&](const std::vector<std::size_t>& region)
//		{
//			// Assign a random color to each region
//			unsigned char r = static_cast<unsigned char>(random.get_int(64, 192));
//			unsigned char g = static_cast<unsigned char>(random.get_int(64, 192));
//			unsigned char b = static_cast<unsigned char>(random.get_int(64, 192));
//			for (const std::size_t& idx : region)
//			{
//				red[idx] = r;
//				green[idx] = g;
//				blue[idx] = b;
//			}
//			++nb_cylinders;
//		}));
//
//
//	return EXIT_SUCCESS;
//}

//int Region_growing_line(Point_set& points, region_prarams& params)
//{
//	std::cerr << points.size() << " points read" << std::endl;
//
//
//	if (!points.has_normal_map())
//	{
//		points.add_normal_map();
//		CGAL::jet_estimate_normals<CGAL::Sequential_tag>(points, 8, points.parameters().degree_fitting(2));
//	}
//
//	// Default parameters for data/cube.pwn
//	const std::size_t k = params.k;
//	const double tolerance = params.distance_threshold;
//	const double max_angle = params.angle_threshold;
//	const std::size_t min_region_size = params.min_region_size;
//
//	// No constraint on radius
//	const double min_radius = params.min_radius;
//	const double max_radius = params.max_radius;
//
//
//	Neighbor_query neighbor_query(points, k, points.point_map());
//	Region_type_line region_type(points, tolerance, max_angle, min_region_size,
//		points.point_map(), points.normal_map());
//	Region_growing_run<Region_type_line> region_growing(points, neighbor_query, region_type);
//
//	// Add maps to get colored output
//	Point_set::Property_map<unsigned char>
//		red = points.add_property_map<unsigned char>("red", 0).first,
//		green = points.add_property_map<unsigned char>("green", 0).first,
//		blue = points.add_property_map<unsigned char>("blue", 0).first;
//
//	CGAL::Random random;
//
//	std::size_t nb_cylinders = 0;
//
//
//	region_growing.detect
//	(boost::make_function_output_iterator
//	([&](const std::vector<std::size_t>& region)
//		{
//			// Assign a random color to each region
//			unsigned char r = static_cast<unsigned char>(random.get_int(64, 192));
//			unsigned char g = static_cast<unsigned char>(random.get_int(64, 192));
//			unsigned char b = static_cast<unsigned char>(random.get_int(64, 192));
//			for (const std::size_t& idx : region)
//			{
//				red[idx] = r;
//				green[idx] = g;
//				blue[idx] = b;
//			}
//			++nb_cylinders;
//		}));
//
//
//	return EXIT_SUCCESS;
//}



// 辅助函数，检查两个集合是否有交集  
bool has_intersection(const std::vector<long long>& a, const std::vector<long long>& b) {
	for (long long num : a) {
		if (std::find(b.begin(), b.end(), num) != b.end()) {
			return true;
		}
	}
	return false;
}

// 辅助函数，合并两个集合  
void union_sets(std::vector<long long>& a, const std::vector<long long>& b) {
	for (long long num : b) {
		if (std::find(a.begin(), a.end(), num) == a.end()) {
			a.push_back(num);
		}
	}
}

// 主函数，合并具有交集的子向量  
void group_and_union(std::vector<std::vector<long long>>& dst) {
	// 标记哪些子向量已经被合并（避免重复合并）  
	std::vector<bool> merged(dst.size(), false);

	// 循环直到没有更多的合并发生  
	bool merged_this_iteration = true;
	while (merged_this_iteration) {
		merged_this_iteration = false;

		// 遍历所有未合并的子向量  
		for (size_t i = 0; i < dst.size(); ++i) {
			if (merged[i]) continue; // 如果已经合并，跳过  

			// 遍历所有其他未合并的子向量  
			for (size_t j = i + 1; j < dst.size(); ++j) {
				if (merged[j]) continue; // 如果已经合并，跳过  

				// 检查两个子向量是否有交集  
				if (has_intersection(dst[i], dst[j])) {
					// 合并子向量j到子向量i  
					union_sets(dst[i], dst[j]);
					merged[j] = true; // 标记j为已合并  
					merged_this_iteration = true; // 表示本轮有合并发生  
				}
			}
		}
	}

	auto rm = std::remove_if(dst.begin(), dst.end(), [&](const std::vector<long long>& vec) {
		return std::find(merged.begin(), merged.end(), true) != merged.end();
		});

	// 移除所有已标记为合并的子向量（除了合并结果的子向量）  
	dst.erase(rm, dst.end());

	// 注意：这里假设合并结果的子向量保留在dst中的第一个位置  
	// 如果需要保留原始顺序或其他逻辑，可能需要更复杂的处理  
}

// 主函数，合并具有交集的子向量  
void group_and_union2(std::vector<std::vector<long long>>& src, std::vector<std::vector<long long>>& dst) {
	// 创建一个映射来跟踪哪些索引被合并到了哪个组  
	std::unordered_map<long long, size_t> index_to_group;
	std::vector<std::vector<long long>> groups; // 存储合并后的组  

	// 遍历所有源向量  
	for (size_t i = 0; i < src.size(); ++i) {
		// 遍历当前源向量的所有索引  
		for (long long index : src[i]) {
			// 如果索引尚未被分配到一个组，则为其创建一个新组  
			if (index_to_group.find(index) == index_to_group.end()) {
				groups.emplace_back(); // 添加一个新组  
				index_to_group[index] = groups.size() - 1; // 将索引映射到该组  
				groups.back().push_back(index); // 将索引添加到新组  
			}
			else {
				// 如果索引已经被分配到一个组，则将其合并到该组  
				size_t group_id = index_to_group[index];
				union_sets(groups[group_id], src[i]); // 合并当前源向量到该组  

				// 更新所有属于当前源向量的索引的组ID  
				for (long long idx : src[i]) {
					if (index_to_group.find(idx) != index_to_group.end() && index_to_group[idx] != group_id) {
						index_to_group[idx] = group_id;
					}
				}
			}
		}
	}

	// 将合并后的组复制到目标向量  
	dst = std::move(groups);
}

int Region_group(Point_set& points, std::vector<Point_set>& points_vs, const char* outputpointspath)
{
	std::vector<float> batch_data;
	int batch_size = 1;
	for (int b = 0; b < batch_size; b++)
	{
		for (long long i = 0; i < points.size();i++)
		{
			batch_data.push_back(points.point(i).x());
			batch_data.push_back(points.point(i).y());
			batch_data.push_back(points.point(i).z());
		}
	}

	const size_t npts = batch_data.size() / 3 / batch_size;
	const size_t dim = 3;
	float* queries = &batch_data[0];
	const size_t nqueries = batch_data.size() / 3 / batch_size;
	const size_t K = 64;
	std::vector<long long> batch_indices;
	batch_indices.resize(batch_size * npts * K);
	knn_batch_omp(&batch_data[0], batch_size, npts, dim, &batch_data[0], nqueries, K, &batch_indices[0]);

	//cpp_knn_batch_distance_pick(&batch_data[0], batch_size, npts, dim, &batch_data[0], nqueries, K, &batch_indices[0]);
	std::vector<std::vector<long long>>  group;
	for (int b = 0; b < batch_size; b++)
	{
		std::cout << "------batch_size------" << b << std::endl;
		for (size_t i = 0; i < nqueries; i++)
		{
			//queries[b * nqueries * dim + i * dim];

			//std::cout << "------------" << std::endl;std::cout << i << std::endl;
			std::vector<long long> ids;
			bool ingroup = false;
			long long groupindex = -1;
			for (size_t j = 0; j < K; j++)
			{
				long long index = batch_indices[b * nqueries * K + i * K + j];
				for (int g = 0; g < group.size(); g++)
				{
					if (std::find(group[g].begin(), group[g].end(), index) != group[g].end())
					{
						groupindex = g;
						break;
					}
				}
				if (groupindex >= 0)
					break;
			}
			if (groupindex < 0)
			{
				group.emplace_back();
				groupindex = group.size() - 1;
			}


			for (size_t j = 0; j < K; j++)
			{
				group[groupindex].push_back(batch_indices[b * nqueries * K + i * K + j]);
			}
			sort(group[groupindex].begin(), group[groupindex].end());
			group[groupindex].erase(std::unique(group[groupindex].begin(), group[groupindex].end()), group[groupindex].end());
			//std::cout << "------------" << std::endl;
		}
	}

	// 标记哪些子向量已经被合并（避免重复合并）  
	std::vector<bool> merged(group.size(), false);

	// 循环直到没有更多的合并发生  
	bool merged_this_iteration = true;
	while (merged_this_iteration) {
		merged_this_iteration = false;

		// 遍历所有未合并的子向量  
		for (size_t i = 0; i < group.size(); ++i) {
			if (merged[i]) continue; // 如果已经合并，跳过  

			// 遍历所有其他未合并的子向量  
			for (size_t j = i + 1; j < group.size(); ++j) {
				if (merged[j]) continue; // 如果已经合并，跳过  

				// 检查两个子向量是否有交集  
				if (has_intersection(group[i], group[j])) {
					// 合并子向量j到子向量i  
					union_sets(group[i], group[j]);
					merged[j] = true; // 标记j为已合并  
					merged_this_iteration = true; // 表示本轮有合并发生  
				}
			}
		}
	}

	for (int i = 0; i < group.size(); i++)
	{
		if (merged[i])
			continue;
		sort(group[i].begin(), group[i].end());
		group[i].erase(std::unique(group[i].begin(), group[i].end()), group[i].end());
		points_vs.emplace_back();
		for (int j = 0; j < group[i].size(); j++)
		{
			points_vs[points_vs.size() - 1].insert(points.point(group[i][j]));
		}

		std::ostringstream oss;
		oss.str("");
		oss << outputpointspath << "/group_" << i << ".ply";
		std::ofstream out(oss.str().c_str());
		CGAL::IO::set_ascii_mode(out);
		out << points_vs[points_vs.size() - 1];
	}

	return 1;
}



int Geometric_classification_of_point_clouds(const char* pointspath, const char* outputpointspath, region_prarams& params)
{
	std::ifstream ifile(CGAL::data_file_path(pointspath));

	Point_set points;
	ifile >> points;


	//CGAL::internal::K_means_clustering k_means(100, points.points().begin()->,
	//    CGAL::internal::K_means_clustering::PLUS_INITIALIZATION)

	std::cerr << points.size() << " points read" << std::endl;


	std::vector<Point_set> points_vs;
	Region_group(points, points_vs, outputpointspath);

	CGAL::Real_timer timer;
	timer.start();
	for (int i = 0; i < points_vs.size(); i++) {

		//无法线生成一下
		if (!points_vs[i].has_normal_map())
		{
			points_vs[i].add_normal_map();
			CGAL::jet_estimate_normals<CGAL::Sequential_tag>(points_vs[i], 8, points_vs[i].parameters().degree_fitting(2));
		}

		if (params.IsRansac)
		{
			ransac(points_vs[i], params);
		}
		else
		{
			switch (params.type)
			{
			case  region_growing_Type::ePlane:
				Region_growing_plane(points_vs[i], params);
				break;
			case region_growing_Type::eCylinder:
				Region_growing_cylinder(points_vs[i], params);
				break;
			case region_growing_Type::eSphere:
				Region_growing_sphere(points_vs[i], params);
				break;
			case region_growing_Type::eCircle:
				//Region_growing_circle(points_vs[i], params);
				break;
			case region_growing_Type::eLine:
				//Region_growing_line(points_vs[i], params);
				break;
			default:
				break;
			}
		}


		std::ostringstream oss;
		oss.str("");
		oss << outputpointspath << "/" << i << ".ply";
		std::ofstream out(oss.str().c_str());
		CGAL::IO::set_ascii_mode(out);
		out << points_vs[i];
	}
	std::cerr << "  detected in " << timer.time() << " seconds" << std::endl;

	return 1;


}

int main(int argc, char** argv)
{
	region_prarams rp;
	// Default parameters for data/cube.pwn
	rp.k = 64;
	rp.distance_threshold = 1;
	rp.angle_threshold = 25;
	rp.min_region_size = 50;
	rp.min_radius = 0;
	rp.max_radius = 90;
	rp.type = region_growing_Type::ePlane;


	std::string srcpoints = "D:\\\\testdata\\building\\Tile_+019_+013_ra.txt";
	//std::string srcpoints = "D:\\\\testdata\\building\\Tile_+019_+013.txt";
	std::string outpath = "D:\\\\testdata\\building";

	Geometric_classification_of_point_clouds(srcpoints.c_str(), outpath.c_str(), rp);

	return 1;
}