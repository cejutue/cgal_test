README:

Data:
To keep the size of this package small, the point_set_3.xyz file is simplified.
The full version, which is used in docs, can be found here:
https://github.com/... /data
