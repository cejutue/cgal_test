#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/IO/read_xyz_points.h>
//#include <CGAL/IO/Writer_OFF.h>
#include <CGAL/Point_set_3/IO.h>
#include <CGAL/property_map.h>
#include <CGAL/Surface_mesh.h>
#include <CGAL/Shape_detection/Efficient_RANSAC.h>
#include <CGAL/Polygonal_surface_reconstruction.h>
#include <CGAL/remove_outliers.h>
#include <CGAL/grid_simplify_point_set.h>
#include <CGAL/compute_average_spacing.h>
#include <CGAL/point_generators_3.h>
#include <CGAL/jet_estimate_normals.h>
#include <CGAL/pca_estimate_normals.h>
#include <CGAL/mst_orient_normals.h>
#include <CGAL/radial_orient_normals.h>
#include <CGAL/vcm_estimate_normals.h>
#include <CGAL/remove_outliers.h>
//#define WRITE_LOG
//#define CGAL_USE_GLPK
#ifdef CGAL_USE_SCIP  // defined (or not) by CMake scripts, do not define by hand

#include <CGAL/SCIP_mixed_integer_program_traits.h>
typedef CGAL::SCIP_mixed_integer_program_traits<double>                        MIP_Solver;

#elif defined(CGAL_USE_GLPK)  // defined (or not) by CMake scripts, do not define by hand

#include <CGAL/GLPK_mixed_integer_program_traits.h>
typedef CGAL::GLPK_mixed_integer_program_traits<double>                        MIP_Solver;

#endif


//#if defined(CGAL_USE_GLPK) || defined(CGAL_USE_SCIP)

#include <CGAL/Timer.h>

#include <fstream>

//
//typedef CGAL::Exact_predicates_inexact_constructions_kernel		Kernel;
//
//typedef Kernel::Point_3											Point;
//typedef Kernel::Vector_3										Vector;
//
//// Point with normal, and plane index
//typedef boost::tuple<Point, Vector, int>						PNI;
//typedef std::vector<PNI>										Point_vector;
////using Point_vector  = CGAL::Point_set_3<PNI>;
//typedef CGAL::Nth_of_tuple_property_map<0, PNI>					Point_map;
//typedef CGAL::Nth_of_tuple_property_map<1, PNI>					Normal_map;
//typedef CGAL::Nth_of_tuple_property_map<2, PNI>					Plane_index_map;
//
//typedef CGAL::Shape_detection::Efficient_RANSAC_traits<Kernel, Point_vector, Point_map, Normal_map>     Traits;
//
//typedef CGAL::Shape_detection::Efficient_RANSAC<Traits>             Efficient_ransac;
//typedef CGAL::Shape_detection::Plane<Traits>                        Plane;
//typedef CGAL::Shape_detection::Sphere<Traits>                       Sphere;
//typedef CGAL::Shape_detection::Cone<Traits>							Cone;
//typedef CGAL::Shape_detection::Torus<Traits>						Torus;
//typedef CGAL::Shape_detection::Cylinder<Traits>						Cylinder;
//
//typedef CGAL::Shape_detection::Point_to_shape_index_map<Traits>     Point_to_shape_index_map;
//
//typedef CGAL::Polygonal_surface_reconstruction<Kernel>                                Polygonal_surface_reconstruction;
//typedef CGAL::Surface_mesh<Point>                                                                        Surface_mesh;

/*
* This example first extracts planes from the input point cloud
* (using RANSAC with default parameters) and then reconstructs
* the surface model from the planes.
*/
/*
����AIʶ�����:
���Ʒָ��һ�����÷���:
�򻯵���: ̫���������
��������: �Ƿ��з���,���û����������  Orientation->Normal Estimation(16,Estimate curvature)
ƽ������: Partition  (RANSAC)
ƽ�油��: �кܶ�û�е���Ҳû�в���,  ��ô�Ͳ�����˶�ƽ���ƽ��
ģ������: Polygonal_surface_reconstruction(MIP ��������滮��������� ����, ò�ƿ��� �ý������)
*/

// Boost includes.
#include <boost/function_output_iterator.hpp>

// CGAL includes.
#include <CGAL/Timer.h>
#include <CGAL/Random.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>

#include <CGAL/Point_set_3.h>
#include <CGAL/Point_set_3/IO.h>

#include <CGAL/Shape_detection/Region_growing/Region_growing.h>
#include <CGAL/Shape_detection/Region_growing/Region_growing_on_point_set.h>
#include <CGAL/jet_smooth_point_set.h>
#include <CGAL/wlop_simplify_and_regularize_point_set.h>

#include <CGAL/structure_point_set.h>
#include <CGAL/Delaunay_triangulation_3.h>
#include <CGAL/Triangulation_vertex_base_with_info_3.h>
#include <CGAL/Advancing_front_surface_reconstruction.h>


#include <CGAL/Scale_space_surface_reconstruction_3.h>
#include <CGAL/Scale_space_reconstruction_3/Jet_smoother.h>
#include <CGAL/Scale_space_reconstruction_3/Advancing_front_mesher.h>
#include <CGAL/Simple_cartesian.h>
#include <CGAL/linear_least_squares_fitting_3.h>
#include <CGAL/Surface_mesh.h>
#include <CGAL/Classification/Point_set_neighborhood.h>
#include "mystruct.h"
	// Type declarations.
using Kernel = CGAL::Exact_predicates_inexact_constructions_kernel;

using FT = typename Kernel::FT;
using Point_3 = typename Kernel::Point_3;
using Vector_3 = typename Kernel::Vector_3;
using Plane_3 = typename Kernel::Plane_3;
using Line_3	 = typename Kernel::Line_3;
using Input_range = CGAL::Point_set_3<Point_3>;
using Point_map = typename Input_range::Point_map;
using Normal_map = typename Input_range::Vector_map;

using Neighbor_query = CGAL::Shape_detection::Point_set::K_neighbor_query<Kernel, Input_range, Point_map>;
using Region_type = CGAL::Shape_detection::Point_set::Least_squares_plane_fit_region<Kernel, Input_range, Point_map, Normal_map>;
using Region_growing = CGAL::Shape_detection::Region_growing<Input_range, Neighbor_query, Region_type>;


using Indices = std::vector<std::size_t>;
using Output_range = CGAL::Point_set_3<Point_3>;
using Points_3 = std::vector<Point_3>;
using Traits = CGAL::Shape_detection::Efficient_RANSAC_traits
<Kernel, Input_range, Input_range::Point_map, Input_range::Vector_map>;
using Efficient_ransac = CGAL::Shape_detection::Efficient_RANSAC<Traits>;
using Plane = CGAL::Shape_detection::Plane<Traits>;
using Sphere = CGAL::Shape_detection::Sphere<Traits>;
using Cone = CGAL::Shape_detection::Cone<Traits>;
using Torus = CGAL::Shape_detection::Torus<Traits>;
using Cylinder = CGAL::Shape_detection::Cylinder<Traits>;
using Point_to_shape_index_map = CGAL::Shape_detection::Point_to_shape_index_map<Traits>;
using Polygonal_surface_reconstruction = CGAL::Polygonal_surface_reconstruction<Kernel>;
using Surface_mesh = CGAL::Surface_mesh<Point_3>;

// Point set structuring type
typedef CGAL::Point_set_with_structure<Kernel>               Structure;
typedef CGAL::Gs_Point_set_with_structure<Kernel>               MyStructure;
typedef std::array<std::size_t, 3> Facet;
// Specialized priority functor that favor structure coherence
template <typename MyStructure>
struct Priority_with_structure_coherence {
	MyStructure& structure;
	double bound;
	Priority_with_structure_coherence(MyStructure& structure,
		double bound)
		: structure(structure), bound(bound)
	{}
	template <typename AdvancingFront, typename Cell_handle>
	double operator() (AdvancingFront& adv, Cell_handle& c,
		const int& index) const
	{
		// If perimeter > bound, return infinity so that facet is not used
		if (bound != 0)
		{
			double d = 0;
			d = sqrt(squared_distance(c->vertex((index + 1) % 4)->point(),
				c->vertex((index + 2) % 4)->point()));
			if (d > bound) return adv.infinity();
			d += sqrt(squared_distance(c->vertex((index + 2) % 4)->point(),
				c->vertex((index + 3) % 4)->point()));
			if (d > bound) return adv.infinity();
			d += sqrt(squared_distance(c->vertex((index + 1) % 4)->point(),
				c->vertex((index + 3) % 4)->point()));
			if (d > bound) return adv.infinity();
		}
		Facet f = { { c->vertex((index + 1) % 4)->info(),
					 c->vertex((index + 2) % 4)->info(),
					 c->vertex((index + 3) % 4)->info() } };
		// facet_coherence takes values between -1 and 3, 3 being the most
		// coherent and -1 being incoherent. Smaller weight means higher
		// priority.
		double weight = 100. * (5 - structure.facet_coherence(f));
		return weight * adv.smallest_radius_delaunay_sphere(c, index);
	}
};


class Index_map {

public:
	using key_type = std::size_t;
	using value_type = int;
	using reference = value_type;
	using category = boost::readable_property_map_tag;

	Index_map() { }
	template<typename PointRange>
	Index_map(
		const PointRange& points,
		const std::vector< std::vector<std::size_t> >& regions) :
		m_indices(new std::vector<int>(points.size(), -1)) {




		for (std::size_t i = 0; i < regions.size(); ++i)
			for (const std::size_t idx : regions[i])
				(*m_indices)[idx] = static_cast<int>(i);

		//��ƽ����Ҫ ����
		(*m_indices)[points.size() - 1] = regions.size();
		(*m_indices)[points.size() - 2] = regions.size();
	}

	inline friend value_type get(
		const Index_map& index_map,
		const key_type key) {

		const auto& indices = *(index_map.m_indices);
		return indices[key];
	}


	void bujiu()
	{

	}
public:
	std::shared_ptr< std::vector<int> > m_indices;
};


struct Insert_point_colored_by_region_index {

	using argument_type = Indices;
	using result_type = void;

	using Color_map =
		typename Output_range:: template Property_map<unsigned char>;

	const Input_range& m_input_range;
	const   Point_map  m_point_map;
	Output_range& m_output_range;
	std::size_t& m_number_of_regions;

	Color_map m_red, m_green, m_blue;

	Insert_point_colored_by_region_index(
		const Input_range& input_range,
		const   Point_map  point_map,
		Output_range& output_range,
		std::size_t& number_of_regions) :
		m_input_range(input_range),
		m_point_map(point_map),
		m_output_range(output_range),
		m_number_of_regions(number_of_regions) {

		m_red =
			m_output_range.template add_property_map<unsigned char>("red", 0).first;
		m_green =
			m_output_range.template add_property_map<unsigned char>("green", 0).first;
		m_blue =
			m_output_range.template add_property_map<unsigned char>("blue", 0).first;
	}

	result_type operator()(const argument_type& region) {

		CGAL::Random rand(static_cast<unsigned int>(m_number_of_regions));
		const unsigned char r =
			static_cast<unsigned char>(64 + rand.get_int(0, 192));
		const unsigned char g =
			static_cast<unsigned char>(64 + rand.get_int(0, 192));
		const unsigned char b =
			static_cast<unsigned char>(64 + rand.get_int(0, 192));

		for (const std::size_t index : region) {
			const auto& key = *(m_input_range.begin() + index);

			const Point_3& point = get(m_point_map, key);
			const auto it = m_output_range.insert(point);

			m_red[*it] = r;
			m_green[*it] = g;
			m_blue[*it] = b;
		}
		++m_number_of_regions;
	}
}; // Insert_point_colored_by_region_index


void  read_myxyz_file1(const char* file, Input_range& point_set)
{

	float   m_xyz[3];

	FILE* pF = fopen(file, "rb");
	int ret = 0;
	do
	{
		if (feof(pF))
			break;
		ret = fread(&m_xyz, 4, 3, pF);
		if (ret <= 0)
			break;
		point_set.insert(Point_3(m_xyz[0], m_xyz[1], m_xyz[2]));

	} while (true);
	fclose(pF);
}

std::string get_name(std::string  filename, const char* s1,const char*s2)
{
	std::string tmpply = filename;
	int g = tmpply.find(s1);
	if (g == tmpply.npos)
		return "";
	tmpply = tmpply.replace(tmpply.find(s1), strlen(s1), s2);
	return tmpply;
}

void  MyStructure_out(MyStructure& mys, std::vector<Point_3>& ps,std::string & filename)
{
	std::string strfile = get_name(filename, ".xyz", "out_point.xyz");
	FILE* pF = fopen(strfile.c_str(), "wt");
	for (std::size_t i = 0; i < mys.m_points.size(); ++i)
	{
		auto& point = mys.m_points[i];
		fprintf(pF, "%lf", point.x());
		fwrite(" ", 1, 1, pF);
		fprintf(pF, "%lf", point.y());
		fwrite(" ", 1, 1, pF);
		fprintf(pF, "%lf", point.z());
		fwrite("\n", 1, 1, pF);
	}
	fclose(pF);

	strfile = get_name(filename, ".xyz", "out_corners.xyz");
	FILE* pF2 = fopen(strfile.c_str(), "wt");
	for (std::size_t i = 0; i < mys.m_corners.size(); ++i)
	{
		auto& point = mys.m_corners[i].support;
		fprintf(pF2, "%lf", point.x());
		fwrite(" ", 1, 1, pF2);
		fprintf(pF2, "%lf", point.y());
		fwrite(" ", 1, 1, pF2);
		fprintf(pF2, "%lf", point.z());
		fwrite("\n", 1, 1, pF2);
	}
	fclose(pF2);

	strfile = get_name(filename, ".xyz", "out_edges.xyz");
	FILE* pF3 = fopen(strfile.c_str(), "wt");
	for (std::size_t i = 0; i < mys.m_edges.size(); ++i)
	{
		auto edge = mys.m_edges[i].indices;
		for (int j = 0; j < edge.size(); j++)
		{
			if (edge[j] >= mys.m_points.size())
				continue;
			auto& point = ps[edge[j]];
fprintf(pF3, "%lf", point.x());
fwrite(" ", 1, 1, pF3);
fprintf(pF3, "%lf", point.y());
fwrite(" ", 1, 1, pF3);
fprintf(pF3, "%lf", point.z());
fwrite("\n", 1, 1, pF3);
		}
	}
	fclose(pF3);

	std::vector<std::vector<Point_3>> Plan_vs = {};
	Plan_vs.resize(mys.m_planes.size());
	strfile = get_name(filename, ".xyz", "out_edges_se.xyz");
	FILE* pF4 = fopen(strfile.c_str(), "wt");
	for (std::size_t i = 0; i < mys.m_edges.size(); ++i)
	{
		auto edge = mys.m_edges[i].indices;
		if (mys.m_edges[i].planes.size() < 2)
			continue;
		int plane1 = mys.m_edges[i].planes[0];
		int plane2 = mys.m_edges[i].planes[1];
		if (edge.size() < 2)
			continue;
		for (int j = 0; j < edge.size(); j++)
		{
			if (j == 0)
			{
				auto& point = ps[edge[j]];
				fprintf(pF4, "%lf", point.x());
				fwrite(" ", 1, 1, pF4);
				fprintf(pF4, "%lf", point.y());
				fwrite(" ", 1, 1, pF4);
				fprintf(pF4, "%lf", point.z());
				fwrite("\n", 1, 1, pF4);
				Plan_vs[plane1].push_back(point);
				Plan_vs[plane2].push_back(point);
			}
			if (edge[j] >= mys.m_points.size())
				continue;
			if (j + 1 >= edge.size())
				break;
			if (edge[j + 1] >= mys.m_points.size())
			{
				auto& point = ps[edge[j]];
				fprintf(pF4, "%lf", point.x());
				fwrite(" ", 1, 1, pF4);
				fprintf(pF4, "%lf", point.y());
				fwrite(" ", 1, 1, pF4);
				fprintf(pF4, "%lf", point.z());
				fwrite("\n", 1, 1, pF4);
				Plan_vs[plane1].push_back(point);
				Plan_vs[plane2].push_back(point);
				break;
			}
		}
	}
	fclose(pF4);
	
	//�߽�ϲ�Ϊ�����
	strfile = get_name(filename, ".xyz", "out_bound.off");
	FILE* pF5 = fopen(strfile.c_str(), "wt");
	int pointszie = 0;
	int planesize = 0;
	std::unordered_map<int, std::vector<int>> plansindex = {};
	for (std::size_t i = 0; i < Plan_vs.size(); ++i)
	{
		if (Plan_vs[i].size() < 3)
			continue;
		for (int j = 0; j < Plan_vs[i].size(); j++)
		{
			plansindex[i].push_back(pointszie);
			pointszie++;
		}
		planesize++;
	}

	fprintf(pF5, "OFF\n");
	fprintf(pF5, "%d %d %d\n", pointszie, planesize, 0);
	for (std::size_t i = 0; i < Plan_vs.size(); ++i)
	{
		if (Plan_vs[i].size() < 3)
			continue;
		for (int j = 0; j < Plan_vs[i].size(); j++)
		{
			fprintf(pF5, "%lf %lf %lf\n", (Plan_vs[i]).at(j).x(), (Plan_vs[i]).at(j).y(), (Plan_vs[i]).at(j).z());
		}
	}
	for (auto it = plansindex.begin(); it != plansindex.end(); ++it)
	{
		fprintf(pF5, "%d ", it->second.size());
		for (int i = 0; i < it->second.size(); i++)
		{
			fprintf(pF5, "%d ", it->second[i]);
		}
		fprintf(pF5, "\n");
	}
	fclose(pF5);
}

void linear_least_squares_fitting_3(MyStructure& mys, std::vector<Point_3>& ps,std::string & filename)
{
	Line_3 lines;
	std::vector<std::vector<Point_3>> Plan_vs = {};
	Plan_vs.resize(mys.m_planes.size());
	//for(int i =0; i < mys.m_indices)
	std::string strfile = get_name(filename, ".xyz", "out_line.xyz");
	FILE* pF4 = fopen(strfile.c_str(), "wt");
	
	fclose(pF4);
}

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Mesh_triangulation_3.h>
#include <CGAL/Mesh_complex_3_in_triangulation_3.h>
#include <CGAL/Mesh_criteria_3.h>
#include <CGAL/Polyhedral_mesh_domain_with_features_3.h>
#include <CGAL/make_mesh_3.h>

int  region_grow(std::string& filename)
{
	CGAL::Timer t;
	// Load xyz data either from a local folder or a user-provided file.
	//std::ifstream  in("data/Tile_+015_+029-twohouser.xyz");
	std::string pathname = filename;//"D:\\testdata\\xyz\\Tile_+014_+029_1.xyz";
	////����ʦ�Ķ����Ƶ���	
	//std::ifstream  in(pathname, std::ifstream::binary);
	////read_myxyz_file1(pathname.c_str(), point_set);

	Input_range point_set;
	Input_range point_setwlop;

	std::ifstream  in(pathname);
	if (!in || !CGAL::read_xyz_point_set(in, point_set))
	{
		std::cerr << "Can't read input file " << std::endl;
		return false;
	}
	//����ʦ�Ķ����Ƶ���	
	//read_myxyz_file1(pathname.c_str(), point_set);

	//Simplify point set
	double per = 90;//50000.0 / point_setwlop.number_of_points() * 100.0;
	const double retain_percentage = per;  // percentage of points to retain.
	const double neighbor_radius = 0.05;   // neighbors size.
	// Concurrency
	double spacing_neighbor_radius = CGAL::compute_average_spacing<CGAL::Sequential_tag>(point_setwlop, 10);
	//using Concurrency_tag = CGAL::Parallel_if_available_tag;
	//auto pointsss = CGAL::make_range(point_setwlop.points().begin(), point_setwlop.points().end());
	//CGAL::wlop_simplify_and_regularize_point_set<Concurrency_tag>
	//	(pointsss, point_set.point_back_inserter(),
	//		CGAL::parameters::select_percentage(retain_percentage).
	//		neighbor_radius(spacing_neighbor_radius));

	const unsigned int nb_neighbors = 24; // considers 24 nearest neighbor points
	// Estimate scale of the point set with average spacing
	const double spacing = CGAL::compute_average_spacing<CGAL::Sequential_tag>
		(point_set, nb_neighbors);
	// FIRST OPTION //
	// I don't know the ratio of outliers present in the point set
	auto first_to_remove
		= CGAL::remove_outliers<CGAL::Sequential_tag>
			(point_set,
				24, // Number of neighbors considered for evaluation
				point_set.parameters().threshold_percent(5.0));
	point_set.remove(first_to_remove, point_set.end());
	point_set.collect_garbage();
	//auto gsim_it = CGAL::grid_simplify_point_set(point_set, 1.21*spacing);
	//point_set.remove(gsim_it, point_set.end());
	CGAL::jet_smooth_point_set<CGAL::Sequential_tag>(point_set, 8);
	//point_set.collect_garbage();

	//auto  box = CGAL::bounding_box(point_set.points().begin(), point_set.points().end());
	//Point_3 pminxy(box.xmin(), box.ymin(), box.zmin());
	//Point_3 pminz(box.xmax(), box.ymax(), box.zmin());
	//Point_3 pminxy1(box.xmin(), box.ymax(), box.zmin());
	//Point_3 pminz1(box.xmax(), box.ymin(), box.zmin());
	//point_set.insert(pminxy);
	//point_set.insert(pminz);
	//point_set.insert(pminxy1);
	//point_set.insert(pminz1);
	if (point_set.has_normal_map())
		point_set.remove_normal_map();
	point_set.add_normal_map();
	CGAL::pca_estimate_normals<CGAL::Sequential_tag>(point_set, 8, point_set.parameters().degree_fitting(2));     // additional named parameter specific to jet_estimate_normals
	//}
	if (!point_set.has_normal_map())
	{
		std::cerr << " Failed: has_normal_map" << std::endl;
		return 0;
	}



	std::cout << "* loaded " << point_set.size() << " points with normals" << std::endl;

	// Default parameter values for the data file point_set_3.xyz.
	const std::size_t k = 12;
	const FT          max_distance_to_plane = FT(spacing *1.32);
	const FT          max_accepted_angle = FT(25);
	const std::size_t min_region_size = 1000;

	// Create instances of the classes Neighbor_query and Region_type.
	Neighbor_query neighbor_query(
		point_set,
		k,
		point_set.point_map());
	

	Region_type region_type(
		point_set,
		max_distance_to_plane, max_accepted_angle, min_region_size,
		point_set.point_map(), point_set.normal_map());

	// Create an instance of the region growing class.
	Region_growing region_growing(
		point_set, neighbor_query, region_type);

	// Run the algorithm.
	Output_range output_range;
	CGAL::Timer timer;
	std::vector< std::vector<std::size_t> > regions;

	timer.start();
	region_growing.detect(std::back_inserter(regions));

	std::size_t number_of_regions = 0;
	Insert_point_colored_by_region_index inserter(
		point_set, point_set.point_map(),
		output_range, number_of_regions);
	region_growing.detect(
		boost::make_function_output_iterator(inserter));
	timer.stop();

	// Print the number of found regions.
	std::cout << "* " << regions.size() << " regions have been found in " << timer.time() << " seconds"
		<< std::endl;
	std::string tmpply = pathname;
	tmpply = tmpply.replace(tmpply.find(".xyz"), 4, "region_index.ply");
	const std::string path = tmpply;//"data/Tile_+015_+029-twohouser3333.ply";
	std::ofstream out(path);
	out << output_range;
	std::cout << "* found regions are saved in " << path << std::endl;
	out.close();


	//Index_map index_map(point_set, regions);
	//Surface_mesh model;

	std::cout << "Reconstructing...";


	using Point_with_normal = std::pair<Kernel::Point_3, Kernel::Vector_3>;
	using Pwn_vector = std::vector<Point_with_normal>;
	using Point_map = CGAL::First_of_pair_property_map<Point_with_normal>;
	using Normal_map = CGAL::Second_of_pair_property_map<Point_with_normal>;

	// Efficient RANSAC types
	using Traits = CGAL::Shape_detection::Efficient_RANSAC_traits
		<Kernel, Pwn_vector, Point_map, Normal_map>;
	using Efficient_ransac = CGAL::Shape_detection::Efficient_RANSAC<Traits>;
	using Plane = CGAL::Shape_detection::Plane<Traits>;
	using LVb = CGAL::Advancing_front_surface_reconstruction_vertex_base_3<Kernel>;
	using LCb = CGAL::Advancing_front_surface_reconstruction_cell_base_3<Kernel>;
	using Tds = CGAL::Triangulation_data_structure_3<LVb, LCb>;
	using Triangulation_3 = CGAL::Delaunay_triangulation_3<Kernel, Tds>;
	using Vertex_handle = Triangulation_3::Vertex_handle;
	typedef std::array<std::size_t, 3> Facet;
	// Functor to init the advancing front algorithm with indexed points
	struct On_the_fly_pair {
		const Pwn_vector& points;
		typedef std::pair<Point_3, std::size_t> result_type;
		On_the_fly_pair(const Pwn_vector& points) : points(points) {}
		result_type
			operator()(std::size_t i) const
		{
			return result_type(points[i].first, i);
		}
	};


	// Advancing front type
	using Reconstruction = CGAL::Advancing_front_surface_reconstruction
		<Triangulation_3,
		Priority_with_structure_coherence<MyStructure> >
		;



	Pwn_vector points;
	std::vector<Point_3> ps;
	std::vector<Vector_3> normals;
	for (int i = 0; i < point_set.size(); i++)
	{
		//points.emplace_back(point_set.point(i), point_set.normal(i));
		ps.emplace_back(point_set.point(i));
		normals.emplace_back(point_set.normal(i));
	}

	//Index_map planes_index_map(ps, regions);
	boost::shared_ptr<std::vector<boost::shared_ptr<Plane> > > planestt
		= boost::make_shared<std::vector<boost::shared_ptr<Plane> > >();
	Efficient_ransac::Plane_range planes(planestt);
	double cluster_epsilon = 1;//max_distance_to_plane;
	double epsilon = 0.05;
	MyStructure pss(points, planes, 0.5,
		CGAL::parameters::point_map(Point_map()).
		normal_map(Normal_map()).plane_map(CGAL::Shape_detection::Plane_map<Traits>()));
	pss.init2(ps, normals, cluster_epsilon, regions);
	MyStructure_out(pss, ps, filename);
	std::cerr << "done \n MyStructure_out... ";
	//return 1;

	////�߶ȿռ��ؽ�
	Pwn_vector structured_pts;
	for (std::size_t i = 0; i < pss.size(); ++i)
		structured_pts.push_back(pss[i]);

	//CGAL::Scale_space_surface_reconstruction_3<Kernel> reconstruct
	//(pss.m_points.begin(), pss.m_points.end());
	//// Smooth using 4 iterations of Jet Smoothing
	//reconstruct.increase_scale(4, CGAL::Scale_space_reconstruction_3::Jet_smoother<Kernel>());
	//// Mesh with the Advancing Front mesher with a maximum facet length of 0.5
	//reconstruct.reconstruct_surface(CGAL::Scale_space_reconstruction_3::Advancing_front_mesher<Kernel>(0.5));


	//Surface_mesh output_mesh_tmp;
	//
	//for (Point_3& pp : CGAL::make_range(reconstruct.points_begin(), reconstruct.points_end()))
	//	output_mesh_tmp.add_vertex(pp);

	//for (auto& facet : CGAL::make_range(reconstruct.facets_begin(), reconstruct.facets_end()))
	//{
	//	Surface_mesh::Vertex_index a(facet[0]), b(facet[1]), c(facet[2]);
	//	output_mesh_tmp.add_face(a, b, c);
	//}
	//std::ofstream f("out_sp8.off");
	//f << output_mesh_tmp;
	//return 1;


	std::cerr << "done\nAdvancing front... ";
	std::vector<std::size_t> point_indices(boost::counting_iterator<std::size_t>(0),
		boost::counting_iterator<std::size_t>(structured_pts.size()));
	Triangulation_3 dt(boost::make_transform_iterator(point_indices.begin(), On_the_fly_pair(structured_pts)),
		boost::make_transform_iterator(point_indices.end(), On_the_fly_pair(structured_pts)));
	Priority_with_structure_coherence<MyStructure> priority(pss, 1000. * cluster_epsilon); // Avoid too large facets
	Reconstruction R(dt, priority);
	R.run();
	std::cerr << "done\nWriting result... ";
	std::vector<Facet> output;
	const Reconstruction::TDS_2& tds = R.triangulation_data_structure_2();
	for (Reconstruction::TDS_2::Face_iterator fit = tds.faces_begin(); fit != tds.faces_end(); ++fit)
		if (fit->is_on_surface())
			output.push_back(CGAL::make_array(fit->vertex(0)->vertex_3()->id(),
				fit->vertex(1)->vertex_3()->id(),
				fit->vertex(2)->vertex_3()->id()));
	std::string strfile = get_name(filename, ".xyz", "out2.off");
	std::ofstream f(strfile);
	f << "OFF\n" << structured_pts.size() << " " << output.size() << " 0\n"; // Header
	for (std::size_t i = 0; i < structured_pts.size(); ++i)
		f << structured_pts[i].first << std::endl;
	for (std::size_t i = 0; i < output.size(); ++i)
		f << "3 "
		<< output[i][0] << " "
		<< output[i][1] << " "
		<< output[i][2] << std::endl;
	std::cerr << "all done\n" << std::endl;
	f.close();




	//// Domain
	//using K = CGAL::Exact_predicates_inexact_constructions_kernel ;
	//using Mesh_domain =  CGAL::Polyhedral_mesh_domain_with_features_3<K> ;
	//// Polyhedron type
	//using Polyhedron =  CGAL::Mesh_polyhedron_3<K>::type ;
	//// Triangulation
	//using Tr =  CGAL::Mesh_triangulation_3<Mesh_domain>::type ;
	//using C3t3 = CGAL::Mesh_complex_3_in_triangulation_3<
	//	Tr, Mesh_domain::Corner_index, Mesh_domain::Curve_index> ;
	//// Criteria
	//using  Mesh_criteria  = CGAL::Mesh_criteria_3<Tr> ;
	//// To avoid verbose function and named parameters call
	//using namespace CGAL::parameters;


	//// 3D Mesh Generation 	�Ż�����
	//Polyhedron poly;
	//std::ifstream input("out2.off");
	//input >> poly;
	//if (!CGAL::is_triangle_mesh(poly)) {
	//	std::cerr << "Input geometry is not triangulated." << std::endl;
	//	return EXIT_FAILURE;
	//}
	//// Create a vector with only one element: the pointer to the polyhedron.
	//std::vector<Polyhedron*> poly_ptrs_vector(1, &poly);
	//// Create a polyhedral domain, with only one polyhedron,
	//// and no "bounding polyhedron", so the volumetric part of the domain will be
	//// empty.
	//Mesh_domain domain(poly_ptrs_vector.begin(), poly_ptrs_vector.end());
	//// Get sharp features
	//domain.detect_features(); //includes detection of borders
	//// Mesh criteria
	//Mesh_criteria criteria(edge_size = 6,
	//	facet_angle = 15,
	//	facet_size =6,
	//	facet_distance = 6);
	//// Mesh generation
	//C3t3 c3t3 = CGAL::make_mesh_3<C3t3>(domain, criteria, no_perturb(), no_exude());
	//// Output the facets of the c3t3 to an OFF file. The facets will not be
	//// oriented.
	//std::ofstream off_file("outmake_mesh_3.off");
	//c3t3.output_boundary_to_off(off_file);
	return 1;
}




int tmain()
{
	std::vector<std::string > files =
	{
		"D:\\testdata\\xyz\\Tile_+000_-021 - Cloud.xyz",
		//"D:\\testdata\\xyz\\kkk.xyz",
	/*	"D:\\testdata\\xyz\\Tile_+014_+029_1.xyz",
		"D:\\testdata\\xyz\\Tile_+014_+029_2.xyz",
		"D:\\testdata\\xyz\\Tile_+014_+029_3.xyz",
		"D:\\testdata\\xyz\\Tile_+014_+029_4.xyz",
		"D:\\testdata\\xyz\\Tile_+014_+029_5.xyz",
		"D:\\testdata\\xyz\\Tile_+014_+029_6.xyz",*/
	};

	#pragma omp parallel for
	for (int i = 0; i < files.size();i++)
	{
		region_grow(files[i]);
	}
	return 1;
}






