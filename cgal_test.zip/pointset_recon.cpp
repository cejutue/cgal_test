#include "stdafx.h"
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Point_set_3.h>
#include <CGAL/Point_set_3/IO.h>
//#include <CGAL/IO/OBJ.h>5.5�汾��
#include <CGAL/IO/ply.h>
#include <CGAL/remove_outliers.h>
#include <CGAL/grid_simplify_point_set.h>
#include <CGAL/jet_smooth_point_set.h>
#include <CGAL/jet_estimate_normals.h>
#include <CGAL/mst_orient_normals.h>
#include <CGAL/poisson_surface_reconstruction.h>
#include <CGAL/Advancing_front_surface_reconstruction.h>
#include <CGAL/Scale_space_surface_reconstruction_3.h>
#include <CGAL/Scale_space_reconstruction_3/Jet_smoother.h>
#include <CGAL/Scale_space_reconstruction_3/Advancing_front_mesher.h>
#include <CGAL/Surface_mesh.h>
#include <CGAL/Polygon_mesh_processing/polygon_soup_to_polygon_mesh.h>
#include <CGAL/Polygon_mesh_processing/triangulate_hole.h>
#include <CGAL/Polygon_mesh_processing/border.h>
#include <CGAL/Polygon_mesh_processing/remesh.h>
#include <CGAL/Iterator_range.h>
#include <CGAL/jet_smooth_point_set.h>
#include <CGAL/IO/read_las_points.h>
#include <cstdlib>
#include <vector>
#include <fstream>
// types


#pragma comment(lib,"3rd_LAStools.lib")


using Kernel = CGAL::Exact_predicates_inexact_constructions_kernel;
using Point_2 = Kernel::Point_2;
using Point_3 = Kernel::Point_3;
using Sphere_3 = Kernel::Sphere_3;
using Segment_3 = Kernel::Segment_3;
using Point_set = CGAL::Point_set_3<Point_3>;
using Vector_3 = Kernel::Vector_3 ;
//using Point_set = CGAL::Point_set_3<Point_3, Vector_3>;
using Mesh = CGAL::Surface_mesh<Point_3>;
typedef std::array<unsigned short, 4> Color;
typedef std::pair<Point_3, Color> PointWithColor;
int main(int argc, char*argv[])
{
	Point_set points;

	int reconstruction_choice
		= ((argc < 4) ? (2) : ( atoi(argv[3])));
	std::string fname = "D:\\testdata\\2021919_06_35_03_000-15-21-15-621.las"; //argv[1];//Tile_ + 015_ + 029 - rgb.xyz
	std::string fnameout = "D:\\testdata\\2021919_06_35_03_000-15-21-15-621.off";//argv[2];
	//std::string fname = argc == 1 ? CGAL::data_file_path("points_3/kitten.xyz") : argv[1];
	if (argc < 2)
	{
		std::cerr << "Usage: " << argv[0] << " [input.xyz/off/ply/las]" << std::endl;
		std::cerr << "Running " << argv[0] << " data/kitten.xyz -1\n";
	}
	std::ifstream stream(fname, std::ios_base::binary);
	if (!stream)
	{
		std::cerr << "Error: cannot read file " << fname << std::endl;
		return EXIT_FAILURE;
	}

	std::ifstream in(fname, std::ios_base::binary);
	std::vector<PointWithColor> pointsw;
	CGAL::IO::read_LAS(fname, points.point_back_inserter());


	
	//for (std::size_t i = 0; i < pointsw.size(); ++i)
	//	points.insert(pointsw[i].first);

	//stream >> points;
	std::cout << "Read " << points.size() << " point(s)" << std::endl;
	if (points.empty())
		return EXIT_FAILURE;
	//typename Point_set::iterator rout_it = CGAL::remove_outliers<CGAL::Sequential_tag>
	//	(points,
	//		24, // Number of neighbors considered for evaluation
	//		points.parameters().threshold_percent(5.0)); // Percentage of points to remove
	//points.remove(rout_it, points.end());
	std::cout << points.number_of_removed_points()
		<< " point(s) are outliers." << std::endl;
	// Applying point set processing algorithm to a CGAL::Point_set_3
	// object does not erase the points from memory but place them in
	// the garbage of the object: memory can be freeed by the user.
	points.collect_garbage();
	// Compute average spacing using neighborhood of 6 points
	double spacing = CGAL::compute_average_spacing<CGAL::Sequential_tag>(points, 10);
	// Simplify using a grid of size 2 * average spacing
	typename Point_set::iterator gsim_it = CGAL::grid_simplify_point_set(points, 2. * spacing);
	points.remove(gsim_it, points.end());
	std::cout << points.number_of_removed_points()
		<< " point(s) removed after simplification." << std::endl;
	points.collect_garbage();
	//CGAL::jet_smooth_point_set<CGAL::Sequential_tag>(points, 24);

	reconstruction_choice = 1;
	if (reconstruction_choice == 0 || reconstruction_choice == -1) // Poisson
	{
		std::cout<< " poisson_surface_reconstruction_delaunay" << std::endl;
		CGAL::jet_estimate_normals<CGAL::Sequential_tag>
			(points, 24); // Use 24 neighbors
		  // Orientation of normals, returns iterator to first unoriented point
		typename Point_set::iterator unoriented_points_begin =
			CGAL::mst_orient_normals(points, 24); // Use 24 neighbors
		points.remove(unoriented_points_begin, points.end());
		CGAL::Surface_mesh<Point_3> output_mesh;
		CGAL::poisson_surface_reconstruction_delaunay
		(points.begin(), points.end(),
			points.point_map(), points.normal_map(),
			output_mesh, spacing);
		fnameout += ".ply";
		std::ofstream f(fnameout, std::ios_base::binary);
		//CGAL::set_binary_mode(f);
		f << output_mesh;
		f.close();
		
	}
	if (reconstruction_choice == 1 || reconstruction_choice == -1) // Advancing front
	{
		std::cout << " advancing_front_surface_reconstruction" << std::endl;
		typedef std::array<std::size_t, 3> Facet; // Triple of indices
		std::vector<Facet> facets;
		// The function is called using directly the points raw iterators
		CGAL::advancing_front_surface_reconstruction(points.points().begin(),
			points.points().end(),
			std::back_inserter(facets));
		std::cout << facets.size()
			<< " facet(s) generated by reconstruction." << std::endl;
		// copy points for random access
		std::vector<Point_3> vertices;
		vertices.reserve(points.size());
		std::copy(points.points().begin(), points.points().end(), std::back_inserter(vertices));
		CGAL::Surface_mesh<Point_3> output_mesh;
		CGAL::Polygon_mesh_processing::polygon_soup_to_polygon_mesh(vertices, facets, output_mesh);
		fnameout += "1.off";
		std::ofstream f(fnameout);
		f << output_mesh;
		f.close();
	}
	if (reconstruction_choice == 2 || reconstruction_choice == -1) // Scale space
	{
		std::cout << " Scale_space_surface_reconstruction_3" << std::endl;
		//�߶ȿռ��ؽ�
		CGAL::Scale_space_surface_reconstruction_3<Kernel> reconstruct
		(points.points().begin(), points.points().end());
		// Smooth using 4 iterations of Jet Smoothing
		reconstruct.increase_scale(8, CGAL::Scale_space_reconstruction_3::Jet_smoother<Kernel>());
		// Mesh with the Advancing Front mesher with a maximum facet length of 0.5
		reconstruct.reconstruct_surface(CGAL::Scale_space_reconstruction_3::Advancing_front_mesher<Kernel>(1));
		std::cout << " reconstruct_surface end " << std::endl;

		std::cout << " output_mesh_tmp  " << std::endl;
		Mesh output_mesh_tmp;
		Mesh output_mesh;
		for (Point_3 & pp : CGAL::make_range(reconstruct.points_begin(), reconstruct.points_end()))
			output_mesh_tmp.add_vertex(pp);

		for (auto& facet : CGAL::make_range(reconstruct.facets_begin(), reconstruct.facets_end()))
		{
			Mesh::Vertex_index a (facet[0]), b(facet[1]), c(facet[2]);
			output_mesh_tmp.add_face(a,b,c);
		}


		fnameout += "2.off";
		std::ofstream f(fnameout);
		f << output_mesh_tmp;
		return EXIT_SUCCESS;

		unsigned int nb_iter = 5;
		
		//��ȡ�߽�
		std::vector<Mesh::Halfedge_index> holes;
		CGAL::Polygon_mesh_processing::extract_boundary_cycles(output_mesh_tmp, std::back_inserter(holes));
		std::cerr << holes.size() << " hole(s) identified" << std::endl;
		//��ն�
		double max_size = 0.;
		Mesh::Halfedge_index outer_hull;
		for (Mesh::Halfedge_index hi : holes)
		{
			CGAL::Bbox_3 hole_bbox;
			for (Mesh::Halfedge_index haf : CGAL::halfedges_around_face(hi, output_mesh_tmp))
			{
				const Point_3& p = output_mesh_tmp.point(target(haf, output_mesh_tmp));
				hole_bbox += p.bbox();
			}
			double size = CGAL::squared_distance(Point_2(hole_bbox.xmin(), hole_bbox.ymin()),
				Point_2(hole_bbox.xmax(), hole_bbox.ymax()));
			if (size > max_size)
			{
				max_size = size;
				outer_hull = hi;
			}
		}
		// Fill all holes except the bigest (which is the outer hull of the mesh)
		for (Mesh::Halfedge_index hi : holes)
			if (hi != outer_hull)
				CGAL::Polygon_mesh_processing::triangulate_refine_and_fair_hole
				(output_mesh_tmp, hi, CGAL::Emptyset_iterator(), CGAL::Emptyset_iterator());


		//���»�������
		//CGAL::Polygon_mesh_processing::isotropic_remeshing(CGAL::make_range(output_mesh_tmp.faces_begin(), output_mesh_tmp.faces_end()), spacing, output_mesh);
		//CGAL::Polygon_mesh_processing::isotropic_remeshing(faces(output_mesh_tmp), spacing, output_mesh);
		//fnameout += "2.off";
		//std::ofstream f(fnameout);
		//f << output_mesh_tmp;

		//std::ofstream f("out_sp3.off");
		//f << "OFF" << std::endl << points.size() << " "
		//	<< reconstruct.number_of_facets() << " 0" << std::endl;
		//for (Point_set::Index idx : points)
		//	f << points.point(idx) << std::endl;
		//for (const auto& facet : CGAL::make_range(reconstruct.facets_begin(), reconstruct.facets_end()))
		//	f << "3 " << facet << std::endl;
		//f.close();
	}
	else // Handle error
	{
		std::cerr << "Error: invalid reconstruction id: " << reconstruction_choice << std::endl;
		return EXIT_FAILURE;
	}
	return EXIT_SUCCESS;
}