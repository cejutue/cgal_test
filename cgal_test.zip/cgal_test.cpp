﻿#include "stdafx.h"

#include <iostream>
#include "cgaldefine.h"


#pragma comment(lib,"libgmp-10.lib")
#pragma comment(lib,"libmpfr-4.lib")
//#include <CGAL/Simple_cartesian.h>
//typedef CGAL::Simple_cartesian<double> Kernel;
//typedef Kernel::Point_2 Point_2;
//typedef Kernel::Segment_2 Segment_2;
//
//
//int testpoint()
//{
//	//!笛卡尔坐标系双精度浮点类型的点和线段
//	Point_2 p(1, 1), q(10, 10);
//	std::cout << "p = " << p << std::endl;
//	std::cout << "q = " << q.x() << " " << q.y() << std::endl;
//	std::cout << "sqdist(p,q) = "
//		<< CGAL::squared_distance(p, q) << std::endl;
//
//	Segment_2 s(p, q);
//	Point_2 m(5, 9);
//
//	std::cout << "m = " << m << std::endl;
//	std::cout << "sqdist(Segment_2(p,q), m) = "
//		<< CGAL::squared_distance(s, m) << std::endl;
//	std::cout << "p, q, and m ";
//	//!方位
//	switch (CGAL::orientation(p, q, m)) {
//
//
//
//	case CGAL::COLLINEAR:
//		std::cout << "are collinear\n";
//		break;
//	case CGAL::LEFT_TURN:
//		std::cout << "make a left turn\n";
//		break;
//	case CGAL::RIGHT_TURN:
//		std::cout << "make a right turn\n";
//		break;
//	}
//	std::cout << " midpoint(p,q) = " << CGAL::midpoint(p, q) << std::endl;
//	system("pause");
//	return 0;
//}


//#include <CGAL/Exact_integer.h>
//#include <CGAL/Homogeneous.h>
//#include <CGAL/Nef_polyhedron_3.h>
//typedef CGAL::Homogeneous<CGAL::Exact_integer>  Kernel;
//typedef CGAL::Nef_polyhedron_3<Kernel> Nef_polyhedron;
//
//int main()
//{
//	Nef_polyhedron N0(Nef_polyhedron::EMPTY);
//	Nef_polyhedron N1(Nef_polyhedron::COMPLETE);
//	CGAL_assertion(N0 == N1.complement());
//	CGAL_assertion(N0 != N1);
//
//}

//
//#include <CGAL/Exact_integer.h>
//#include <CGAL/Extended_homogeneous.h>
//#include <CGAL/Nef_polyhedron_3.h>
//typedef CGAL::Exact_integer  NT;
//typedef CGAL::Extended_homogeneous<NT>  Kernel;
//typedef CGAL::Nef_polyhedron_3<Kernel>  Nef_polyhedron;
//typedef Nef_polyhedron::Plane_3  Plane_3;
//typedef Kernel::Plane_3 Plane_3;
//int main() {
//	Nef_polyhedron N1(Plane_3(2, 5, 7, 11), Nef_polyhedron::INCLUDED);
//	Nef_polyhedron N2(Plane_3(2, 5, 7, 11), Nef_polyhedron::EXCLUDED);
//	CGAL_assertion(N1 >= N2);
//	CGAL_assertion(N2 <= N1);
//	CGAL_assertion(N1 != N2);
//	CGAL_assertion(N1 > N2);
//	CGAL_assertion(N2 < N1);
//	N2 = N2.closure();
//	CGAL_assertion(N1 == N2);
//	CGAL_assertion(N1 >= N2);
//	CGAL_assertion(N1 <= N2);
//	return 0;
//}


//#include <CGAL/Exact_integer.h>
//#include <CGAL/Homogeneous.h>
//
//#include <CGAL/Nef_polyhedron_3.h>
//#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
//typedef CGAL::Exact_integer  NT;
//typedef CGAL::Homogeneous<NT>  Kernel;
//typedef CGAL::Nef_polyhedron_3<Kernel>  Nef_polyhedron;
//int main() {
//	Nef_polyhedron N;
//	std::cin >> N;
//	CGAL_assertion((N - N.boundary()) == N.interior());
//	CGAL_assertion(N.closure() == N.complement().interior().complement());
//	CGAL_assertion(N.regularization() == N.interior().closure());
//	N.intersection(N);
//
//	return 0;
//}
#define		CGAL_TYPE	GeoStar::Kernel::CGALData 




typedef		CGAL_TYPE::CGAL_Point2				Gs_Point2;
typedef		CGAL_TYPE::CGAL_Point3				Gs_Point3;
typedef		CGAL_TYPE::CGAL_Bbox2				Gs_Box2;
typedef		CGAL_TYPE::CGAL_Bbox3				Gs_Box3;
typedef		CGAL_TYPE::CGAL_Line2				Gs_Line2;
typedef		CGAL_TYPE::CGAL_Line3				Gs_Line3;
typedef		CGAL_TYPE::CGAL_Path2				Gs_Path2;
typedef		CGAL_TYPE::CGAL_Polyline3			Gs_Polyline2;
typedef		CGAL_TYPE::CGAL_Path3				Gs_Path3;
typedef		CGAL_TYPE::CGAL_Polyline3			Gs_Polyline3;

typedef		CGAL_TYPE::CGAL_Segment3			Gs_Segment3;
typedef		CGAL_TYPE::CGAL_Polygon				Gs_Polygon;
typedef		CGAL_TYPE::CGAL_Polygon_with_holes	Gs_Polygon_With_Holes;
typedef		CGAL_TYPE::CGAL_Exact_Polyhedron	Gs_Polyhedron2;
typedef		CGAL_TYPE::CGAL_Nef_polyhedron2		Gs_Nef_Polyhedron2;
typedef		CGAL_TYPE::CGAL_Polyhedron			Gs_Polyhedron3;
typedef		CGAL_TYPE::CGAL_Nef_polyhedron3		Gs_Nef_Polyhedron3;
typedef		CGAL_TYPE::CGAL_Plane3				Gs_Plane3;
typedef		CGAL_TYPE::CGAL_Direction_3			Gs_Direction_3;
typedef		CGAL_TYPE::CGAL_AABB_Tree			Gs_AABB_Tree;
typedef		CGAL_TYPE::CGAL_Surface_Mesh		Gs_Surface_Mesh;
//CGAL::convert_nef_polyhedron_to_polygon_mesh
//int main() {
//	//构造两个多面体
//	Gs_Polyhedron3 cube1, cube2;
//	fill_cube_1(cube1);
//	fill_cube_2(cube2);
//	Gs_Nef_Polyhedron3 nef1(cube1);
//	Gs_Nef_Polyhedron3 nef2(cube2);
//	//交
//	auto t = nef1.intersection(nef2);
//
//	//并
//	nef1.join(nef2);
//	//对称差
//	nef1.symmetric_difference(nef2);
//	//差
//	nef1.difference(nef2);
//	//凸包
//	nef1.boundary();
//	//
//	nef1.simplify();
//	nef1.is_simple();
//
//	//	Gs_Point2 p2;
//	Gs_Point3 p3;
//	Gs_Box2 b2;
//	Gs_Box3 b3;
//	//	Gs_Line2 l2;
//	Gs_Line3 l3;
//	//	Gs_Path2 pa2;
//	Gs_Polyline2 pl2;
//	Gs_Path3 pa3;
//	Gs_Polyline3 pl3;
//
//	Gs_Segment3 s3;
//	Gs_Polygon po;
//	Gs_Polygon_With_Holes pos;
//	Gs_Polyhedron3 ep;
//	Gs_Nef_Polyhedron2 np2;
//	Gs_Nef_Polyhedron3 np3;
//	Gs_Plane3 plan3;
//	Gs_Direction_3 d3;
//	Gs_AABB_Tree aabb;
//	Gs_Surface_Mesh sm;
//
//}

//#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
//#include <CGAL/Surface_mesh.h>
//#include <CGAL/Polygon_mesh_processing/corefinement.h>
//#include <fstream>
//typedef CGAL::Exact_predicates_inexact_constructions_kernel K;
//typedef CGAL::Surface_mesh<K::Point_3>             Mesh;
//namespace PMP = CGAL::Polygon_mesh_processing;
//int Test(int argc, char* argv[])
//{
//	const char* filename1 = (argc > 1) ? argv[1] : "data/blobby.off";
//	const char* filename2 = (argc > 2) ? argv[2] : "data/eight.off";
//	std::ifstream input(filename1);
//	Mesh mesh1, mesh2;
//	
//	if (!input || !(input >> mesh1))
//	{
//		std::cerr << "First mesh is not a valid off file." << std::endl;
//		return 1;
//	}
//	input.close();
//	input.open(filename2);
//	if (!input || !(input >> mesh2))
//	{
//		std::cerr << "Second mesh is not a valid off file." << std::endl;
//		return 1;
//	}
//	Mesh out;
//	bool valid_union = PMP::corefine_and_compute_union(mesh1, mesh2, out);
//	if (valid_union)
//	{
//		std::cout << "Union was successfully computed\n";
//		std::ofstream output("union.off");
//		output.precision(17);
//		output << out;
//		return 0;
//	}
//	std::cout << "Union could not be computed\n";
//	return 1;
//}

void fill_cube_1(Gs_Polyhedron3& poly)
{
	std::string input =
		"OFF\n\
8 12 0\n\
-1 -1 -1\n\
-1 1 -1\n\
1 1 -1\n\
1 -1 -1\n\
-1 -1 1\n\
-1 1 1\n\
1 1 1\n\
1 -1 1\n\
3  0 1 3\n\
3  3 1 2\n\
3  0 4 1\n\
3  1 4 5\n\
3  3 2 7\n\
3  7 2 6\n\
3  4 0 3\n\
3  7 4 3\n\
3  6 4 7\n\
3  6 5 4\n\
3  1 5 6\n\
3  2 1 6";
	std::stringstream ss;
	ss << input;
	ss >> poly;
}
void fill_cube_2(Gs_Polyhedron3& poly)
{
	std::string input =
		"OFF\n\
8 12 0\n\
-0.5 -0.5 -0.5\n\
-0.5 0.5 -0.5\n\
0.5 0.5 -0.5\n\
0.5 -0.5 -0.5\n\
-0.5 -0.5 0.5\n\
-0.5 0.5 0.5\n\
0.5 0.5 0.5\n\
0.5 -0.5 0.5\n\
3  0 1 3\n\
3  3 1 2\n\
3  0 4 1\n\
3  1 4 5\n\
3  3 2 7\n\
3  7 2 6\n\
3  4 0 3\n\
3  7 4 3\n\
3  6 4 7\n\
3  6 5 4\n\
3  1 5 6\n\
3  2 1 6";
	std::stringstream ss;
	ss << input;
	ss >> poly;
}
#include <CGAL/Simple_cartesian.h>
#include <CGAL/Surface_mesh.h>

#include <CGAL/Surface_mesh_simplification/edge_collapse.h>
#include <CGAL/Surface_mesh_simplification/Policies/Edge_collapse/Count_ratio_stop_predicate.h>

#include <chrono>
#include <fstream>
#include <iostream>

//typedef CGAL::Simple_cartesian<CGAL::Gmpq>               Kernel;
typedef CGAL::Simple_cartesian<double>               Kernel;
typedef Kernel::Point_3                              Point_3;
typedef CGAL::Surface_mesh<Point_3>                  Surface_mesh;

namespace SMS = CGAL::Surface_mesh_simplification;

int bmain(int argc, char** argv)
{
	Surface_mesh surface_mesh;
	const char* filename = (argc > 1) ? argv[1] : "D:\\3D\\reconstruct\\PoissonRecon-master\\Bin\\x64\\Release\\15_8182_16396_pointosgb.ply";// "D:/source/kernel/example/cgal_test/data/mesh_with_border.off";
	std::ifstream is(filename);
	if (!is || !(is >> surface_mesh))
	{
		std::cerr << "Failed to read input mesh: " << filename << std::endl;
		return EXIT_FAILURE;
	}

	if (!CGAL::is_triangle_mesh(surface_mesh))
	{
		std::cerr << "Input geometry is not triangulated." << std::endl;
		return EXIT_FAILURE;
	}

	std::chrono::steady_clock::time_point start_time = std::chrono::steady_clock::now();

	// In this example, the simplification stops when the number of undirected edges
	// drops below 10% of the initial count
	double stop_ratio = (argc > 2) ? std::stod(argv[2]) : 0.1;
	SMS::Count_ratio_stop_predicate<Surface_mesh> stop(stop_ratio);

	int r = SMS::edge_collapse(surface_mesh, stop);

	std::chrono::steady_clock::time_point end_time = std::chrono::steady_clock::now();

	std::cout << "\nFinished!\n" << r << " edges removed.\n" << surface_mesh.number_of_edges() << " final edges.\n";
	std::cout << "Time elapsed: " << std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count() << "ms" << std::endl;

	std::ofstream os(argc > 3 ? argv[3] : "mesh_with_border_out.off");
	os.precision(17);
	os << surface_mesh;

	return EXIT_SUCCESS;
}


