#pragma once

// Construction kernel
#include "CGAL/Exact_predicates_exact_constructions_kernel.h"
#include "CGAL/Exact_predicates_inexact_constructions_kernel.h"

// Polygon
#include "CGAL/Nef_polyhedron_2.h"
#include "CGAL/Polygon_2.h"
#include "CGAL/Polygon_with_holes_2.h"

// Polyhedron
#include "CGAL/convex_hull_3.h"
#include "CGAL/Polyhedron_3.h"
#include "CGAL/Polyhedron_incremental_builder_3.h"
#include "CGAL/Nef_polyhedron_3.h"
#include "CGAL/IO/Polyhedron_iostream.h"
#include "CGAL/IO/Nef_polyhedron_iostream_3.h"

// Utils
#include "CGAL/exceptions.h"
#include "CGAL/assertions.h"
#include "CGAL/assertions_behaviour.h"
#include "CGAL/utils.h"
#include "CGAL/Real_timer.h"
#include "CGAL/bounding_box.h"

// Straight skeleton
#include "CGAL/Straight_skeleton_builder_2.h"
#include "CGAL/Polygon_offset_builder_2.h"
#include "CGAL/compute_outer_frame_margin.h"
#include "CGAL/create_straight_skeleton_2.h"
#include "CGAL/create_straight_skeleton_from_polygon_with_holes_2.h"

// Surface mesh
#include "CGAL/Surface_mesh.h"
#include "CGAL/Surface_mesh_default_triangulation_3.h"
#include "CGAL/Complex_2_in_triangulation_3.h"
#include "CGAL/Side_of_triangle_mesh.h"
#include "CGAL/boost/graph/graph_traits_Surface_mesh.h"
#include "CGAL/make_surface_mesh.h"
#include "CGAL/Surface_mesh_default_criteria_3.h"
#include "CGAL/Implicit_surface_3.h"

// Polygon mesh processing
#include "CGAL/Polygon_mesh_processing/bbox.h"
#include "CGAL/Polygon_mesh_processing/self_intersections.h"
#include "CGAL/Polygon_mesh_processing/stitch_borders.h"
#include "CGAL/Polygon_mesh_processing/orientation.h"

// Delaunay triangulation
#include "CGAL/Constrained_Delaunay_triangulation_2.h"
#include "CGAL/Triangulation_face_base_with_info_2.h"
#include "CGAL/Delaunay_mesher_2.h"
#include "CGAL/Delaunay_mesh_face_base_2.h"
#include "CGAL/Delaunay_mesh_size_criteria_2.h"

// AABB tree for cutting plane
//#include "CGAL/AABB_intersections.h"
#include "CGAL/AABB_tree.h"
#include "CGAL/AABB_traits.h"
#include "CGAL/boost/graph/graph_traits_Polyhedron_3.h"
#include "CGAL/AABB_halfedge_graph_segment_primitive.h"
#include "CGAL/AABB_face_graph_triangle_primitive.h"

// Poisson for Point Cloud
//#include "CGAL/trace.h"
#include "CGAL/Surface_mesh_default_triangulation_3.h"
#include "CGAL/make_surface_mesh.h"
#include "CGAL/Implicit_surface_3.h"
#include "CGAL/Poisson_reconstruction_function.h"
#include "CGAL/Point_with_normal_3.h"
#include "CGAL/property_map.h"
#include "CGAL/compute_average_spacing.h"

// IO
#include "CGAL/IO/Complex_2_in_triangulation_3_file_writer.h"
#include "CGAL/IO/facets_in_complex_2_to_triangle_mesh.h"
#include "CGAL/IO/output_surface_facets_to_polyhedron.h"

//#ifdef CGAL_EIGEN3_ENABLED
//#include "CGAL/Eigen_solver_traits.h"
//#endif

//#include "Base3D/UGPolySet.h"

#include "CGAL/GMP/Gmpq_type.h"
namespace GeoStar
{
	namespace Kernel
	{
		namespace CGALData
		{

			// ����Ҫ��
			typedef CGAL::Color CGAL_Color;
			typedef CGAL::Bbox_2 CGAL_Bbox2;
			typedef CGAL::Bbox_3 CGAL_Bbox3;

			// Kernel2�ṹ
			typedef CGAL::Gmpq NT2;
			typedef CGAL::Extended_cartesian<NT2> CGAL_Kernel2;

			typedef CGAL::Point_2<CGAL_Kernel2> CGAL_Point2;
			typedef CGAL::Line_2<CGAL_Kernel2> CGAL_Line2;

			// ��ά����νṹ
			typedef CGAL::Polygon_2<CGAL_Kernel2> CGAL_Polygon;
			typedef CGAL::Polygon_with_holes_2<CGAL_Kernel2> CGAL_Polygon_with_holes;

			// ��ά����
			typedef CGAL_Kernel2::Aff_transformation_2 CGAL_Aff_transformation2;

			// Kernel3�ṹ
			typedef CGAL::Exact_predicates_exact_constructions_kernel	CGAL_Exact_Kernel3;
			typedef CGAL::Exact_predicates_inexact_constructions_kernel CGAL_Inexact_Kernel3;
			typedef CGAL_Exact_Kernel3 CGAL_Kernel3;

			typedef CGAL::Simple_cartesian<double> CGAL_Simple_Kernel;
			typedef CGAL::Epick CGAL_Epick_Kernel;

			// ��ά����
			typedef CGAL_Exact_Kernel3::Aff_transformation_3 CGAL_Exact_transformation3;
			typedef CGAL_Inexact_Kernel3::Aff_transformation_3 CGAL_Inexact_transformation3;
			typedef CGAL_Exact_transformation3 CGAL_transformation3;

			// ��ά������
			typedef CGAL::Polyhedron_3<CGAL_Exact_Kernel3> CGAL_Exact_Polyhedron;
			typedef CGAL::Polyhedron_3<CGAL_Inexact_Kernel3> CGAL_Inexact_Polyhedron;
			typedef CGAL_Exact_Polyhedron CGAL_Polyhedron;

			// Boolean operations work only with exact kernel
			typedef CGAL::Nef_polyhedron_2<CGAL_Kernel2> CGAL_Nef_polyhedron2;
			typedef CGAL::Nef_polyhedron_3<CGAL_Exact_Kernel3> CGAL_Nef_polyhedron3;

			// ��ά��������
			typedef CGAL::Point_3<CGAL_Exact_Kernel3> CGAL_Exact_Point3;
			typedef CGAL::Point_3<CGAL_Inexact_Kernel3> CGAL_Inexact_Point3;
			typedef CGAL_Exact_Point3 CGAL_Point3;

			typedef CGAL::Line_3<CGAL_Exact_Kernel3> CGAL_Exact_Line3;
			typedef CGAL::Line_3<CGAL_Inexact_Kernel3> CGAL_Inexact_Line3;
			typedef CGAL_Exact_Line3 CGAL_Line3;

			typedef CGAL::Segment_3<CGAL_Exact_Kernel3> CGAL_Exact_Segment3;
			typedef CGAL::Segment_3<CGAL_Inexact_Kernel3> CGAL_Inexact_Segment3;
			typedef CGAL_Exact_Segment3 CGAL_Segment3;

			typedef CGAL::Vector_3<CGAL_Exact_Kernel3> CGAL_Exact_Vector3;
			typedef CGAL::Vector_3<CGAL_Inexact_Kernel3> CGAL_Inexact_Vector3;
			typedef CGAL_Exact_Vector3 CGAL_Vector3;

			typedef CGAL::Plane_3<CGAL_Exact_Kernel3> CGAL_Exact_Plane3;
			typedef CGAL::Plane_3<CGAL_Inexact_Kernel3> CGAL_Inexact_Plane3;
			typedef CGAL_Exact_Plane3 CGAL_Plane3;

			typedef CGAL::Direction_3<CGAL_Exact_Kernel3> CGAL_Exact_Direction_3;
			typedef CGAL::Direction_3<CGAL_Inexact_Kernel3> CGAL_Inexact_Direction_3;
			typedef CGAL_Exact_Direction_3 CGAL_Direction_3;

			// AABB Tree
			typedef CGAL::AABB_face_graph_triangle_primitive<CGAL_Exact_Polyhedron> CGAL_Exact_AABB_Primetive;
			typedef CGAL::AABB_face_graph_triangle_primitive<CGAL_Inexact_Polyhedron> CGAL_Inexact_AABB_Primetive;

			typedef CGAL::AABB_traits<CGAL_Exact_Kernel3, CGAL_Exact_AABB_Primetive> CGAL_Exact_AABB_Traits;
			typedef CGAL::AABB_traits<CGAL_Inexact_Kernel3, CGAL_Inexact_AABB_Primetive> CGAL_Inexact_AABB_Traits;

			typedef CGAL::AABB_tree<CGAL_Exact_AABB_Traits> CGAL_Exact_AABB_Tree;
			typedef CGAL::AABB_tree<CGAL_Inexact_AABB_Traits> CGAL_Inexact_AABB_Tree;
			typedef CGAL_Exact_AABB_Tree CGAL_AABB_Tree;

			// Surface Mesh
			typedef CGAL::Surface_mesh<CGAL_Exact_Point3> CGAL_Exact_Surface_Mesh;
			typedef CGAL::Surface_mesh<CGAL_Inexact_Point3> CGAL_Inexact_Surface_Mesh;
			typedef CGAL_Exact_Surface_Mesh CGAL_Surface_Mesh;
			

			typedef CGAL_Point2	* Point2_iterator;
			typedef std::pair<Point2_iterator, Point2_iterator> Point2_range;
			typedef std::list<Point2_range> CGAL_Path2;
			typedef CGAL_Path2* Path2_iterator;
			typedef std::vector<Path2_iterator> CGAL_Polyline2;

			typedef CGAL_Point3	* Point3_iterator;
			typedef std::pair<Point3_iterator, Point3_iterator> Point3_range;
			typedef std::list<Point3_range> CGAL_Path3;
			typedef CGAL_Path3* Path3_iterator;
			typedef std::vector<Path3_iterator> CGAL_Polyline3;
		}

	}
}